﻿namespace Security_Algorithms
{
    partial class DES_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Go_Button = new System.Windows.Forms.Button();
            this.Key_TextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.KindOfKey_ComboBox = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // Go_Button
            // 
            this.Go_Button.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Go_Button.Location = new System.Drawing.Point(276, 5);
            this.Go_Button.Name = "Go_Button";
            this.Go_Button.Size = new System.Drawing.Size(50, 30);
            this.Go_Button.TabIndex = 9;
            this.Go_Button.Text = "Go";
            this.Go_Button.UseVisualStyleBackColor = true;
            this.Go_Button.Click += new System.EventHandler(this.Go_Button_Click);
            // 
            // Key_TextBox
            // 
            this.Key_TextBox.Location = new System.Drawing.Point(52, 11);
            this.Key_TextBox.Name = "Key_TextBox";
            this.Key_TextBox.Size = new System.Drawing.Size(136, 20);
            this.Key_TextBox.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(9, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 14);
            this.label1.TabIndex = 7;
            this.label1.Text = "Key :";
            // 
            // KindOfKey_ComboBox
            // 
            this.KindOfKey_ComboBox.FormattingEnabled = true;
            this.KindOfKey_ComboBox.Items.AddRange(new object[] {
            "Text",
            "Hex"});
            this.KindOfKey_ComboBox.Location = new System.Drawing.Point(194, 10);
            this.KindOfKey_ComboBox.Name = "KindOfKey_ComboBox";
            this.KindOfKey_ComboBox.Size = new System.Drawing.Size(76, 21);
            this.KindOfKey_ComboBox.TabIndex = 14;
            // 
            // DES_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(334, 44);
            this.Controls.Add(this.KindOfKey_ComboBox);
            this.Controls.Add(this.Go_Button);
            this.Controls.Add(this.Key_TextBox);
            this.Controls.Add(this.label1);
            this.Name = "DES_Form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DES Algorithm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Go_Button;
        private System.Windows.Forms.TextBox Key_TextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox KindOfKey_ComboBox;
    }
}