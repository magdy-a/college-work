﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Security_Algorithms
{
    public partial class DiffieHellman_Form : Form
    {
        public DiffieHellman_Form()
        {
            InitializeComponent();
            Q_TextBox.Text = "19";
            Alpha_TextBox.Text = "2";
            UserA_X_TextBox.Text = "8";
            UserB_X_TextBox.Text = "3";
        }

        private void Go_Button_Click(object sender, EventArgs e)
        {
            int Q, Alpha, UserA_X, UserB_X, UserA_Y, UserB_Y, UserA_K, UserB_K;
            if (Q_TextBox.Text != "" && Alpha_TextBox.Text != "" && UserA_X_TextBox.Text != "" && UserB_X_TextBox.Text != "")
            {
                Q = int.Parse(Q_TextBox.Text);
                Alpha = int.Parse(Alpha_TextBox.Text);
                UserA_X = int.Parse(UserA_X_TextBox.Text);
                UserB_X = int.Parse(UserB_X_TextBox.Text);
                if (UserA_X < Q && UserB_X < Q)
                {
                    UserA_Y = CalculatePower(Alpha, UserA_X, Q);
                    UserB_Y = CalculatePower(Alpha, UserB_X, Q);
                    UserA_Y_TextBox.Text = UserA_Y.ToString();
                    UserB_Y_TextBox.Text = UserB_Y.ToString();

                    UserA_K = CalculatePower(UserB_Y, UserA_X, Q);
                    UserB_K = CalculatePower(UserA_Y, UserB_X, Q);
                    UserA_K_TextBox.Text = UserA_K.ToString();
                    UserB_K_TextBox.Text = UserB_K.ToString();

                }
                else
                    MessageBox.Show("(X) Value should Small than (Q) Value");
            }
            else
                MessageBox.Show("Some Input is Empty ... !!!");
        }
        private int CalculatePower(int Base, int Power, int other)
        {
            int Result = 1;
            List<int> P = Powers(Power);
            for (int i = 0; i < P.Count; i++)
            {
                Result *= ((int)Math.Pow((double)Base, P[i])) % other;
            }
            Result = Result % other;
            
            return Result;
        }
        private List<int> Powers(int Number)
        {
            List<int> Result = new List<int>();
            int sum = 0;
            int temp = 1;
            while (temp + sum <= Number)
            {
                Result.Add(temp);
                sum += temp;
                temp *= 2;
            }
            int index = Result.Count - 1;
            while (sum != Number && index >= 0)
            {
                if (Result[index] + sum <= Number)
                {
                    Result.Add(Result[index]);
                    sum += Result[index];
                }
                else
                    index--;
            }
            return Result;
        }

    }
}
