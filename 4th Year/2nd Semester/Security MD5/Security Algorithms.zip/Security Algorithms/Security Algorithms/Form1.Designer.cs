﻿namespace Security_Algorithms
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.PlainText_TextBox = new System.Windows.Forms.TextBox();
            this.CipherText_TextBox = new System.Windows.Forms.TextBox();
            this.ListOfAlgorithms_ComboBox = new System.Windows.Forms.ComboBox();
            this.Encrypt_Button = new System.Windows.Forms.Button();
            this.Decrypt_Button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // PlainText_TextBox
            // 
            this.PlainText_TextBox.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PlainText_TextBox.Location = new System.Drawing.Point(123, 12);
            this.PlainText_TextBox.Multiline = true;
            this.PlainText_TextBox.Name = "PlainText_TextBox";
            this.PlainText_TextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.PlainText_TextBox.Size = new System.Drawing.Size(367, 123);
            this.PlainText_TextBox.TabIndex = 0;
            // 
            // CipherText_TextBox
            // 
            this.CipherText_TextBox.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CipherText_TextBox.Location = new System.Drawing.Point(123, 141);
            this.CipherText_TextBox.Multiline = true;
            this.CipherText_TextBox.Name = "CipherText_TextBox";
            this.CipherText_TextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.CipherText_TextBox.Size = new System.Drawing.Size(367, 117);
            this.CipherText_TextBox.TabIndex = 1;
            // 
            // ListOfAlgorithms_ComboBox
            // 
            this.ListOfAlgorithms_ComboBox.FormattingEnabled = true;
            this.ListOfAlgorithms_ComboBox.Items.AddRange(new object[] {
            "Ceaser Cipher",
            "Monoalphapetic",
            "Polyalphabetic",
            "Pley Fair",
            "Rail Fence",
            "Columnar",
            "Hill Cipher",
            "DES",
            "3DES",
            "AES",
            "RC4",
            "MD5",
            "RSA",
            "DiffieHellman",
            "MultiplicativeInverse"});
            this.ListOfAlgorithms_ComboBox.Location = new System.Drawing.Point(12, 124);
            this.ListOfAlgorithms_ComboBox.Name = "ListOfAlgorithms_ComboBox";
            this.ListOfAlgorithms_ComboBox.Size = new System.Drawing.Size(101, 21);
            this.ListOfAlgorithms_ComboBox.TabIndex = 2;
            this.ListOfAlgorithms_ComboBox.SelectedIndexChanged += new System.EventHandler(this.ListOfAlgorithms_ComboBox_SelectedIndexChanged);
            // 
            // Encrypt_Button
            // 
            this.Encrypt_Button.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Encrypt_Button.Location = new System.Drawing.Point(22, 43);
            this.Encrypt_Button.Name = "Encrypt_Button";
            this.Encrypt_Button.Size = new System.Drawing.Size(75, 45);
            this.Encrypt_Button.TabIndex = 3;
            this.Encrypt_Button.Text = "Encrypt";
            this.Encrypt_Button.UseVisualStyleBackColor = true;
            this.Encrypt_Button.Click += new System.EventHandler(this.Encrypt_Button_Click);
            // 
            // Decrypt_Button
            // 
            this.Decrypt_Button.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Decrypt_Button.Location = new System.Drawing.Point(22, 178);
            this.Decrypt_Button.Name = "Decrypt_Button";
            this.Decrypt_Button.Size = new System.Drawing.Size(75, 45);
            this.Decrypt_Button.TabIndex = 4;
            this.Decrypt_Button.Text = "Decrypt";
            this.Decrypt_Button.UseVisualStyleBackColor = true;
            this.Decrypt_Button.Click += new System.EventHandler(this.Decrypt_Button_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(498, 270);
            this.Controls.Add(this.Decrypt_Button);
            this.Controls.Add(this.Encrypt_Button);
            this.Controls.Add(this.ListOfAlgorithms_ComboBox);
            this.Controls.Add(this.CipherText_TextBox);
            this.Controls.Add(this.PlainText_TextBox);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Security Algorithms";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox PlainText_TextBox;
        private System.Windows.Forms.TextBox CipherText_TextBox;
        private System.Windows.Forms.ComboBox ListOfAlgorithms_ComboBox;
        private System.Windows.Forms.Button Encrypt_Button;
        private System.Windows.Forms.Button Decrypt_Button;
    }
}

