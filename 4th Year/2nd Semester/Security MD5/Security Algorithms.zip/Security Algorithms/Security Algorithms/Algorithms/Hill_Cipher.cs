﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Security_Algorithms
{
    class Hill_Cipher : Security_Algorithms
    {
        private int Number_Key;
        private int[,] Matrix;

        public Hill_Cipher()
        {

        }
        public Hill_Cipher(int number_key, int[,] matrix)
        {
            this.Number_Key = number_key;
            this.Matrix = matrix;
        }

        public override string EncryptText(string PlainText)
        {
            string CipherText = string.Empty;
            int[] Plaintext_Matrix = new int[Number_Key];
            int[] Result_Mult = new int[Number_Key];

            for (int i = 0; i < PlainText.Length; i += Number_Key)
            {
                for (int j = 0; j < Number_Key; j++)
                    Plaintext_Matrix[j] = ((int)PlainText[i + j] - 97);

                Result_Mult= Mult_Matrix(Plaintext_Matrix);

                for (int j = 0; j < Number_Key; j++)
                    CipherText += (char)(Result_Mult[j] + 97);
            }

            return CipherText;
        }
        public override string DecryptText(string CipherText)
        {
            string PlainText = string.Empty;
            PlainText = "Not Emplmented Yet... ";
            return PlainText;
        }

        private int[] Mult_Matrix(int[] SingleMatix)
        {
            int[] Value = new int[Number_Key];
            int Local_Value;
            for (int i = 0; i < Number_Key; i++)
            {
                Local_Value = 0;
                for (int j = 0; j < Number_Key; j++)
                {
                    Local_Value += Matrix[i, j] * SingleMatix[j];
                }
                Value[i] = Local_Value % 26;
            }
            return Value;
        }
    }
}
