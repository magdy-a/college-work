﻿using System;

namespace Security_Algorithms
{
    class RC4 : Security_Algorithms
    {
        #region Properites

        private string Key;
        public char[] KeyChar;
        public int[] Key_Block;


        #endregion

        public RC4(string key)
        {
            this.Key = key;
        }

        public override string EncryptText(string PlainText)
        {

            string CipherText = string.Empty;
            int[] PlainAscii = GetASCII(PlainText);
            //  string[] KeySplitted = Key.Split(',');
            int[] KeyAscii;

            Pseudo_Random_Generator(PlainText);

            KeyAscii = GetASCII(Key);

            Key_Block = KeyAscii;
            for (int i = 0; i < KeyAscii.Length; i++)
            {
                string temp1 = Convert.ToString(PlainAscii[i]);
                string temp2 = Convert.ToString(KeyAscii[i]);
                CipherText += Make_XOR(temp1, temp2);
            }
            return CipherText;
        }
        public override string DecryptText(string CipherText)
        {
            string PlainText = string.Empty;
            int[] CipherAscii = GetASCII(CipherText);
            for (int i = 0; i < CipherAscii.Length; i++)
            {
                string temp1 = Convert.ToString(CipherAscii[i]);
                string temp2 = Convert.ToString(Key_Block[i]);
                CipherText += Make_XOR(temp1, temp2);

            }
            return PlainText;
        }


        #region Secondary Method
        public int[] GetASCII(string Key)
        {
            KeyChar = Key.ToCharArray();
            int[] ASCIICode = new int[Key.Length];
            for (int i = 0; i < Key.Length; i++)
            {
                ASCIICode[i] = KeyChar[i];
            }
            return ASCIICode;
        }
        public void Pseudo_Random_Generator(string Plain_text)
        {

            KeyChar = Key.ToCharArray();
            string[] KeyString = new string[Key.Length];
            int[] Ascii = GetASCII(Key);
            int i, j, k;
            int[] State = new int[256];
            string[] Temp = new string[256];


            for (i = 0; i < Key.Length; i++)
            {
                KeyString[i] = string.Format("{0:X} ", Ascii[i]);
            }

            for (i = 0; i < 255; i++)
            {
                State[i] = i;
                Temp[i] = KeyString[i % Key.Length];
            }

            j = 0;
            for (i = 0; i < 255; i++)
            {
                j = (j + State[i] + Convert.ToInt32(Temp[i])) % 256;
                Swap(ref State[i], ref State[j]);
            }

            i = 0;
            j = 0;
            int lenght = 0;
            while (lenght++ < Plain_text.Length)
            {
                i = (i + 1) % 256;
                j = (j + State[i]) % 256;
                Swap(ref State[i], ref State[j]);
                k = State[(State[i] + State[j]) % 256];
                Console.WriteLine(k);
            }
        }
        static void Swap<T>(ref T lhs, ref T rhs)
        {
            T temp;
            temp = lhs;
            lhs = rhs;
            rhs = temp;
        }
        public string Make_XOR(string var1, string var2)
        {
            while (var1.Length != var2.Length)
            {
                if (var1.Length < var2.Length)
                {
                    var1 = "0" + var1;
                }
                else
                {
                    var2 = "0" + var2;
                }
            }
            char[] VarChar = var1.ToCharArray();
            char[] Var2Char = var2.ToCharArray();
            int count = 0;
            String res = "";
            while (count < var1.Length)
            {
                if (VarChar[count] != Var2Char[count])
                { res += "1"; }
                else
                {
                    res += "0";
                }
                count++;
            }
            return Convert.ToString(int.Parse(res));
        }
        #endregion
    }
}
