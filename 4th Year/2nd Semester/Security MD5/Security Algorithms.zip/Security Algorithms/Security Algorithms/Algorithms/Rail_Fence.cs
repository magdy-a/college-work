﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Security_Algorithms
{
    class Rail_Fence : Security_Algorithms
    {
        private int Depth;

        public Rail_Fence()
        {
            Depth = 0;
        }
        public Rail_Fence(int depth)
        {
            this.Depth = depth;
        }

        public override string EncryptText(string PlainText)
        {
            string CipherText = string.Empty;
            double S = (double)PlainText.Length / Depth;
            int Size = (int)Math.Ceiling(S);
            char[,] Matrix = new char[Depth, Size];
            int k = 0;
            for (int i = 0; i < Size; i++)
            {
                for (int j = 0; j < Depth; j++)
                {
                    Matrix[j, i] = PlainText[k++];
                    if (k == PlainText.Length)
                        break;
                }
            }
            k = 0;
            for (int i = 0; i < Depth; i++)
            {
                for (int j = 0; j < Size; j++)
                {
                    CipherText += Matrix[i,j];
                    k++;
                    if (k == PlainText.Length)
                        break;
                }
            }
            //int Temp = 0;
            //for (int i = 0,z=Temp; i < PlainText.Length; i++)
            //{
            //    if (z == PlainText.Length - Depth)
            //        z = (++Temp);
            //    CipherText += PlainText[z];
            //    z += Depth;
            //}
            return CipherText;
        }
        public override string DecryptText(string CipherText)
        {
            string PlainText = string.Empty;
            CipherText = CipherText.Replace(" ", string.Empty);
            double S = (double)CipherText.Length / Depth;
            int Size = (int)Math.Ceiling(S);
            char[,] Matrix = new char[Depth, Size];
            int k = 0;
            for (int i = 0; i < Depth; i++)
            {
                for (int j = 0; j < Size; j++)
                {
                    Matrix[i, j] = CipherText[k++];
                    if (k == CipherText.Length)
                        break;
                }
            }
            k = 0;
            for (int i = 0; i < Size; i++)
            {
                for (int j = 0; j < Depth; j++)
                {
                    PlainText += Matrix[j, i];
                    k++;
                    if (k == CipherText.Length)
                        break;
                }
            }
            return PlainText;
        }
    }
}
