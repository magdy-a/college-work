﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Security_Algorithms
{
    class TripleDes : Security_Algorithms
    {
        #region Properites
        private string FirstKey;
        private string SecondKey;
        private bool KindOfKey; // True -> Text , False -> Hex
        #endregion

        public TripleDes(string first_key, string second_key, bool Kind_of_Key)
        {
            this.FirstKey = first_key;
            this.SecondKey = second_key;
            this.KindOfKey = Kind_of_Key;
        }

        public override string EncryptText(string PlainText)
        {
            string CipherText = string.Empty;
            DES Des1 = new DES(this.FirstKey, this.KindOfKey);
            DES Des2 = new DES(this.SecondKey, this.KindOfKey);
            string Result = string.Empty;

            Result = Des1.EncryptText(PlainText);
            Result = Des2.DecryptText(Result);
            CipherText = Des1.EncryptText(Result);

            return CipherText;
        }
        public override string DecryptText(string CipherText)
        {
            string PlainText = string.Empty;
            DES Des1 = new DES(this.FirstKey, this.KindOfKey);
            DES Des2 = new DES(this.SecondKey, this.KindOfKey);
            string Result = string.Empty;

            Result = Des1.DecryptText(CipherText);
            Result = Des2.EncryptText(Result);
            PlainText = Des1.DecryptText(Result);

            return PlainText;
        }
    }
}
