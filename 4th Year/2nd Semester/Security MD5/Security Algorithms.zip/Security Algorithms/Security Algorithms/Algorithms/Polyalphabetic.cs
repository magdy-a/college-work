﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Security_Algorithms
{
    class Polyalphabetic : Security_Algorithms
    {
        private string Key;
        private string AlphaKey = "abcdefghijklmnopqrstuvwxyz";
        private Polyalphabetic_Key Kind_Of_Key;

        public Polyalphabetic()
        {
            this.Key = "hello";
            this.Kind_Of_Key = Polyalphabetic_Key.RepeatedKey;
        }
        public Polyalphabetic(string key)
        {
            this.Key = key;
            Kind_Of_Key = Polyalphabetic_Key.RepeatedKey;
        }
        public Polyalphabetic(string key , Polyalphabetic_Key kind_of_key)
        {
            this.Key = key;
            this.Kind_Of_Key = kind_of_key;
        }
        
        public override string EncryptText(string PlainText)
        {
            string CipherText = string.Empty;
            string UsingKey = string.Empty;

            if (Kind_Of_Key == Polyalphabetic_Key.RepeatedKey)
            {
                    for (int i = 0; i < PlainText.Length; i++)
                        UsingKey += Key[i % Key.Length];
            }
            else
            {
                UsingKey = Key;
                if(UsingKey.Length < PlainText.Length)
                    for (int i = 0; i < (PlainText.Length - Key.Length); i++)
                        UsingKey += PlainText[i];
            }

            int Index1, Index2, Index3;
            for (int i = 0; i < PlainText.Length; i++)
            {
                Index1 = AlphaKey.IndexOf(PlainText[i]);
                Index2 = AlphaKey.IndexOf(UsingKey[i]);
                Index3 = (Index1 + Index2) % 26;
                CipherText += AlphaKey[Index3];
            }
            return CipherText;
        }
        public override string DecryptText(string CipherText)
        {
            string PlainText = string.Empty;
            string UsingKey = string.Empty;
            int Index1, Index2, Index3;

            if (Kind_Of_Key == Polyalphabetic_Key.RepeatedKey)
            {
                for (int i = 0; i < CipherText.Length; i++)
                    UsingKey += Key[i % Key.Length];
                for (int i = 0; i < CipherText.Length; i++)
                {
                    Index1 = AlphaKey.IndexOf(CipherText[i]);
                    Index2 = AlphaKey.IndexOf(UsingKey[i]);
                    Index3 = (26 + (Index1 - Index2)) % 26;
                    PlainText += AlphaKey[Index3];
                }
            }
            else
            {
                UsingKey = Key;
                for (int i = 0; i < CipherText.Length; i++)
                {
                    Index1 = AlphaKey.IndexOf(CipherText[i]);
                    Index2 = AlphaKey.IndexOf(UsingKey[i]);
                    Index3 = (26 + (Index1 - Index2)) % 26;
                    PlainText += AlphaKey[Index3];
                    UsingKey += AlphaKey[Index3];
                }
            }
            return PlainText;
        }
    }
    public enum Polyalphabetic_Key{ AutoKey , RepeatedKey}
}
