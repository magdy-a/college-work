﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Security_Algorithms
{
    class AES : Security_Algorithms
    {
        #region Properites
        private string Key;
        private bool KindOfKey; // True -> Text , False -> Hex
        private string[,] Matrix_Key;
        private string[,] Key_Schedule;
        private string[,] S_Box = { { "SBox", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F" },
                                  { "0", "63", "7C", "77", "7B", "F2", "6B", "6F", "C5", "30", "01", "67", "2B", "FE", "D7", "AB", "76" },
                                  { "1", "CA", "82", "C9", "7D", "FA", "59", "47", "F0", "AD", "D4", "A2", "AF", "9C", "A4", "72", "C0" },
                                  { "2", "B7", "FD", "93", "26", "36", "3F", "F7", "CC", "34", "A5", "E5", "F1", "71", "D8", "31", "15" },
                                  { "3", "04", "C7", "23", "C3", "18", "96", "05", "9A", "07", "12", "80", "E2", "EB", "27", "B2", "75" },
                                  { "4", "09", "83", "2C", "1A", "1B", "6E", "5A", "A0", "52", "3B", "D6", "B3", "29", "E3", "2F", "84" },
                                  { "5", "53", "D1", "00", "ED", "20", "FC", "B1", "5B", "6A", "CB", "BE", "39", "4A", "4C", "58", "CF" },
                                  { "6", "D0", "EF", "AA", "FB", "43", "4D", "33", "85", "45", "F9", "02", "7F", "50", "3C", "9F", "A8" },
                                  { "7", "51", "A3", "40", "8F", "92", "9D", "38", "F5", "BC", "B6", "DA", "21", "10", "FF", "F3", "D2" },
                                  { "8", "CD", "0C", "13", "EC", "5F", "97", "44", "17", "C4", "A7", "7E", "3D", "64", "5D", "19", "73" },
                                  { "9", "60", "81", "4F", "DC", "22", "2A", "90", "88", "46", "EE", "B8", "14", "DE", "5E", "0B", "DB" },
                                  { "A", "E0", "32", "3A", "0A", "49", "06", "24", "5C", "C2", "D3", "AC", "62", "91", "95", "E4", "79" },
                                  { "B", "E7", "C8", "37", "6D", "8D", "D5", "4E", "A9", "6C", "56", "F4", "EA", "65", "7A", "AE", "08" },
                                  { "C", "BA", "78", "25", "2E", "1C", "A6", "B4", "C6", "E8", "DD", "74", "1F", "4B", "BD", "8B", "8A" },
                                  { "D", "70", "3E", "B5", "66", "48", "03", "F6", "0E", "61", "35", "57", "B9", "86", "C1", "1D", "9E" },
                                  { "E", "E1", "F8", "98", "11", "69", "D9", "8E", "94", "9B", "1E", "87", "E9", "CE", "55", "28", "DF" },
                                  { "F", "8C", "A1", "89", "0D", "BF", "E6", "42", "68", "41", "99", "2D", "0F", "B0", "54", "BB", "16" } };
        private string[,] Xor_Table = { { "XOR", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F" },
                                      { "0", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F" },
                                      { "1", "1", "0", "3", "2", "5", "4", "7", "6", "9", "8", "B", "A", "D", "C", "F", "E" },
                                      { "2", "2", "3", "0", "1", "6", "7", "4", "5", "A", "B", "8", "9", "E", "F", "C", "D" },
                                      { "3", "3", "2", "1", "0", "7", "6", "5", "4", "B", "A", "9", "8", "F", "E", "D", "C" },
                                      { "4", "4", "5", "6", "7", "0", "1", "2", "3", "C", "D", "E", "F", "8", "9", "A", "B" },
                                      { "5", "5", "4", "7", "6", "1", "0", "3", "2", "D", "C", "F", "E", "9", "8", "B", "A" },
                                      { "6", "6", "7", "4", "5", "2", "3", "0", "1", "E", "F", "C", "D", "A", "B", "8", "9" },
                                      { "7", "7", "6", "5", "4", "3", "2", "1", "0", "F", "E", "D", "C", "B", "A", "9", "8" },
                                      { "8", "8", "9", "A", "B", "C", "D", "E", "F", "0", "1", "2", "3", "4", "5", "6", "7" },
                                      { "9", "9", "8", "B", "A", "D", "C", "F", "E", "1", "0", "3", "2", "5", "4", "7", "6" },
                                      { "A", "A", "B", "8", "9", "E", "F", "C", "D", "2", "3", "0", "1", "6", "7", "4", "5" },
                                      { "B", "B", "A", "9", "8", "F", "E", "D", "C", "3", "2", "1", "0", "7", "6", "5", "4" },
                                      { "C", "C", "D", "E", "F", "8", "9", "A", "B", "4", "5", "6", "7", "0", "1", "2", "3" },
                                      { "D", "D", "C", "F", "E", "9", "8", "B", "A", "5", "4", "7", "6", "1", "0", "3", "2" },
                                      { "E", "E", "F", "C", "D", "A", "B", "8", "9", "6", "7", "4", "5", "2", "3", "0", "1" },
                                      { "F", "F", "E", "D", "C", "B", "A", "9", "8", "7", "6", "5", "4", "3", "2", "1", "0" } };
        private string[,] RCon = { { "01", "02", "04", "08", "10", "20", "40", "80", "1b", "36" },
                                 { "00", "00", "00", "00", "00", "00", "00", "00", "00", "00" },
                                 { "00", "00", "00", "00", "00", "00", "00", "00", "00", "00" },
                                 { "00", "00", "00", "00", "00", "00", "00", "00", "00", "00" } };

        #endregion

        public AES(string key)
        {
            this.Key = key;
            this.KindOfKey = true;
        }
        public AES(string key, bool Kind_of_Key)
        {
            this.KindOfKey = Kind_of_Key;
            if (KindOfKey)
                this.Key = TextToHex(key);
            else
                this.Key = key;
            Intial_Key();
        }

        public override string EncryptText(string PlainText)
        {
            string CipherText = string.Empty;
            string[,] Matrix_PlainText;
            string[,] AddRoundKey_Result;
            string[,] SubBytes_Result;
            string[,] ShiftRows_Result;
            string[,] MixColumns_Result;
            string[,] Temp_round_Key;
            if (KindOfKey)
                PlainText = TextToHex(PlainText);

            Intial_Key_Schedule();
            Matrix_PlainText = Intial_PlainText(PlainText);

            AddRoundKey_Result = AddRoundKey(Matrix_PlainText, Matrix_Key);     //Initial Round
            for (int i = 1; i <= 9; i++)
            {
                SubBytes_Result = SubBytes(AddRoundKey_Result);
                ShiftRows_Result = ShiftRows(SubBytes_Result);
                MixColumns_Result = MixColumns(ShiftRows_Result);
                Temp_round_Key = GetRoundKey(Key_Schedule, i);  //To Get Special valus of Used #Round
                AddRoundKey_Result = AddRoundKey(MixColumns_Result, Temp_round_Key);
            }

            //Final Round #10
            SubBytes_Result = SubBytes(AddRoundKey_Result);
            ShiftRows_Result = ShiftRows(SubBytes_Result);
            Temp_round_Key = GetRoundKey(Key_Schedule, 10);
            AddRoundKey_Result = AddRoundKey(ShiftRows_Result, Temp_round_Key);

            #region Test case
            //for (int i = 0; i < 4; i++)
            //{
            //    for (int j = 0; j < 4; j++)
            //    {
            //        CipherText += Matrix_PlainText[i, j] + " , ";
            //    }
            //    CipherText += "\r\n";
            //}
            //CipherText += "----------------------\r\n";

            //for (int i = 0; i < 4; i++)
            //{
            //    for (int j = 0; j < 4; j++)
            //    {
            //        CipherText += AddRoundKey_Result[i, j] + " , ";
            //    }
            //    CipherText += "\r\n";
            //}
            //CipherText += "----------------------\r\n";

            //for (int i = 0; i < 4; i++)
            //{
            //    for (int j = 0; j < 4; j++)
            //    {
            //        CipherText += SubBytes_Result[i, j] + " , ";
            //    }
            //    CipherText += "\r\n";
            //}
            //CipherText += "----------------------\r\n";

            //for (int i = 0; i < 4; i++)
            //{
            //    for (int j = 0; j < 4; j++)
            //    {
            //        CipherText += ShiftRows_Result[i, j] + " , ";
            //    }
            //    CipherText += "\r\n";
            //}
            //for (int i = 0; i < 4; i++)
            //{
            //    for (int j = 0; j < 20; j++)
            //    {
            //        CipherText += Key_Schedule[i, j] + " , ";
            //    }
            //    CipherText += "\r\n";
            //}
            #endregion

            return CipherText;
        }
        public override string DecryptText(string CipherText)
        {
            string PlainText = string.Empty;
            PlainText = "Decryption is not emplmented yet... ";
            return PlainText;
        }

        #region Secondary Method
        private string TextToHex(string Text)
        {
            string Temp = string.Empty;
            int value;
            for (int i = 0; i < Text.Length; i++)
            {
                value = (int)Convert.ToUInt32(Text[i]);
                Temp += string.Format("{0:X} , ", value);
            }
            return Temp;
        }
        private void Intial_Key()
        {
            Matrix_Key = new string[4, 4];
            int K = 0;
            for (int i = 0; i < 4; i++)
                for (int j = 0; j < 4; j++)
                    Matrix_Key[j, i] = Key[K++].ToString() + Key[K++].ToString();
        }
        private void Intial_Key_Schedule()
        {
            Key_Schedule = new string[4, 44];
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    Key_Schedule[i, j] = Matrix_Key[i, j];
                }
            }
            string[] Temp1 = new string[4];
            for (int i = 4; i < 44; i++)
            {
                if (i % 4 == 0) // first Column in each Round
                {
                    for (int j = 0; j < 4; j++)
                    {
                        Key_Schedule[j, i] = Key_Schedule[(j + 1) % 4, i - 1];
                        Key_Schedule[j, i] = Get_From_SBox(Key_Schedule[j, i]); // SubBytes
                        Key_Schedule[j, i] = Xor_For_Hex(RCon[j, (i / 4) - 1], Xor_For_Hex(Key_Schedule[j, i - 4], Key_Schedule[j, i]));
                    }
                }
                else
                {
                    for (int j = 0; j < 4; j++)
                    {
                        Key_Schedule[j, i] = Xor_For_Hex(Key_Schedule[j, i - 1], Key_Schedule[j, i - 4]);
                    }
                }
            }

        }
        private string[,] Intial_PlainText(string Text)
        {
            string[,] Temp = new string[4, 4];
            int K = 0;
            for (int i = 0; i < 4; i++)
                for (int j = 0; j < 4; j++)
                    Temp[j, i] = Text[K++].ToString() + Text[K++].ToString();

            return Temp;
        }
        private string Xor_For_Hex(string Hex1, string Hex2)
        {
            string Temp = string.Empty;
            int X0, X1, Y0, Y1;

            X0 = GetIndex(Hex1[0]);
            Y0 = GetIndex(Hex2[0]);
            X1 = GetIndex(Hex1[1]);
            Y1 = GetIndex(Hex2[1]);

            Temp += Xor_Table[X0, Y0];
            Temp += Xor_Table[X1, Y1];
            return Temp;

        }
        private string[,] AddRoundKey(string[,] First, string[,] Second)
        {
            string[,] Temp = new string[4, 4];
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    Temp[i, j] = Xor_For_Hex(First[i, j], Second[i, j]);
                }
            }
            return Temp;
        }
        private string[,] SubBytes(string[,] Text)
        {
            string[,] Temp = new string[4, 4];

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    Temp[i, j] = Get_From_SBox(Text[i, j]);
                }
            }
            return Temp;
        }
        private string[,] ShiftRows(string[,] Text)
        {
            string[,] Temp = new string[4, 4];
            for (int i = 0; i < 4; i++)
            {
                for (int j = i; j < i + 4; j++)
                {
                    Temp[i, j - i] = Text[i, j % 4];
                }
            }
            return Temp;
        }
        private string[,] MixColumns(string[,] Text)
        {
            string[,] Temp = new string[4, 4];

            return Temp;
        }
        private string Get_From_SBox(string Text)
        {
            int X = GetIndex(Text[0]);
            int Y = GetIndex(Text[1]);

            return S_Box[X, Y];
        }
        private int GetIndex(char ch)
        {
            switch (ch)
            {
                case '0':
                    return 1;
                case '1':
                    return 2;
                case '2':
                    return 3;
                case '3':
                    return 4;
                case '4':
                    return 5;
                case '5':
                    return 6;
                case '6':
                    return 7;
                case '7':
                    return 8;
                case '8':
                    return 9;
                case '9':
                    return 10;
                case 'A':
                case 'a':
                    return 11;
                case 'B':
                case 'b':
                    return 12;
                case 'C':
                case 'c':
                    return 13;
                case 'D':
                case 'd':
                    return 14;
                case 'E':
                case 'e':
                    return 15;
                case 'F':
                case 'f':
                    return 16;
                default:
                    return -1;
            }
        }
        private string[,] GetRoundKey(string[,] Text, int Number)
        {
            string[,] Temp = new string[4, 4];
            int Index = Number * 4;
            for (int i = 0; i < 4; i++)
            {
                for (int j = Index; j < Index + 4; j++)
                {
                    Temp[i, j % 4] = Key_Schedule[i, j];
                }
            }
            return Temp;
        }
        #endregion
    }
}
