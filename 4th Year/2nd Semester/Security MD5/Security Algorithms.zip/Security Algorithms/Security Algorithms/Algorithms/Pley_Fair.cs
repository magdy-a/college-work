﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace Security_Algorithms
{
    class Pley_Fair : Security_Algorithms
    {
        private string Key = "abcdefghiklmnopqrstuvwxyz";   // abcdefghijklmnopqrstuvwxyz
        private string KeyWord, UsingKey;
        private char[,] MatrixKey;


        public Pley_Fair()
        {
            //this.KeyWord = "pleyfair";
            this.KeyWord = "hello";
            UsingKey = string.Empty;
            SetUsingKey();
            MatrixKey = new char[5, 5];
            SetMatrixKey();
        }
        public Pley_Fair(string Key_Word)
        {
            this.KeyWord = Key_Word;
            UsingKey = string.Empty;
            SetUsingKey();
            MatrixKey = new char[5, 5];
            SetMatrixKey();
        }

        public override string EncryptText(string PlainText)
        {
            string CipherText = string.Empty;
            string UsingPlainText = EditPlainText(PlainText);

            Point P1 = new Point();
            Point P2 = new Point();
            for (int i = 0; i < UsingPlainText.Length; i += 2)
            {
                P1 = FindPosition(UsingPlainText[i]);
                P2 = FindPosition(UsingPlainText[i + 1]);

                if (P1.Y == P2.Y)   //Same Row
                {
                    CipherText += MatrixKey[(P1.X + 1) % 5, P1.Y].ToString() + MatrixKey[(P2.X + 1) % 5, P2.Y].ToString();
                }
                else if (P1.X == P2.X)  //Same Column
                {
                    CipherText += MatrixKey[P1.X, (P1.Y + 1) % 5].ToString() + MatrixKey[P2.X, (P2.Y + 1) % 5].ToString();
                }
                else
                {
                    CipherText += MatrixKey[P1.X, P2.Y].ToString() + MatrixKey[P2.X, P1.Y].ToString();
                }
            }
            //return UsingPlainText;
            return CipherText;
        }
        public override string DecryptText(string CipherText)
        {
            string PlainText = string.Empty;
            Point P1 = new Point();
            Point P2 = new Point();
            for (int i = 0; i < CipherText.Length; i += 2)
            {
                P1 = FindPosition(CipherText[i]);
                P2 = FindPosition(CipherText[i + 1]);
                if (P1.Y == P2.Y)   //Same Row
                {
                    PlainText += MatrixKey[(P1.X + 4) % 5, P1.Y].ToString() + MatrixKey[(P2.X + 4) % 5, P2.Y].ToString();
                }
                else if (P1.X == P2.X)  //Same Column
                {
                    PlainText += MatrixKey[P1.X, (P1.Y + 4) % 5].ToString() + MatrixKey[P2.X, (P2.Y + 4) % 5].ToString();
                }
                else
                {
                    PlainText += MatrixKey[P1.X, P2.Y].ToString() + MatrixKey[P2.X, P1.Y].ToString();
                }
            }
            return PlainText;
        }

        private void SetUsingKey()
        {
            for (int i = 0; i < KeyWord.Length; i++)
            {
                if (UsingKey.IndexOf(KeyWord[i]) == -1)
                {
                    UsingKey += KeyWord[i];
                }
            }
            for (int i = 0; i < Key.Length; i++)
            {
                if (UsingKey.IndexOf(Key[i]) == -1)
                {
                    UsingKey += Key[i];
                }
            }
        }
        public string GetUsingKey()
        {
            return UsingKey;
        }
        private void SetMatrixKey()
        {
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    MatrixKey[i, j] = UsingKey[i * 5 + j];
                }
            }
        }
        public string GetMatrixKey()
        {
            string Temp = string.Empty;
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    Temp += MatrixKey[i, j];
                }
            }
            return Temp;
        }
        private string EditPlainText(string PlainText)
        {
            string Separator = "x";
            for (int i = 0; i < PlainText.Length; i++)
            {
                if (i == PlainText.Length - 1) // One Charachter
                {
                    PlainText = PlainText.Insert(i + 1, Separator);
                    i++;
                }
                else if (PlainText[i] == PlainText[i + 1]) // Same Character
                {
                    PlainText = PlainText.Insert(i + 1, Separator);
                    i++;
                }
                else // Default Case
                {
                    i++;
                }
            }
            return PlainText;
        }
        private Point FindPosition(char ch)
        {
            Point P = new Point();
            P.X = P.Y = -1;
            if (ch == 'j')
                ch = 'i';

            for (int i = 0; i < 5; i++)
                for (int j = 0; j < 5; j++)
                    if (ch == MatrixKey[i, j])
                    {
                        P.X = i;
                        P.Y = j;
                        return P;
                    }

            return P;
        }
    }
}
