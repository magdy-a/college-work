﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Security_Algorithms
{
    class Ceaser_Cipher : Security_Algorithms
    {
        private int NumberOfShift;
        private string Key;

        public Ceaser_Cipher()
        { 
            this.NumberOfShift = 3;
            this.Key = "abcdefghijklmnopqrstuvwxyz";
        }
        public Ceaser_Cipher(int Number_Of_Shift)
        {
            this.NumberOfShift = Number_Of_Shift;
            this.Key = "abcdefghijklmnopqrstuvwxyz";
        }
        public Ceaser_Cipher(string key)
        {
            this.Key = key;
        }
        public Ceaser_Cipher(int Number_Of_Shift, string key)
        {
            this.NumberOfShift = Number_Of_Shift;
            this.Key = key;
        }

        public override string EncryptText(string PlainText)
        {
            string CipherText = string.Empty;
            int Index;
            for (int i = 0; i < PlainText.Length; i++)
            {
                if (char.IsLetter(PlainText[i]))
                {
                    Index = Key.IndexOf(char.ToLower(PlainText[i]));
                    Index= (Index + NumberOfShift) % 26;
                    CipherText += (char.IsLower(PlainText[i]) ? (char)(Index+97) : (char)(Index+65));
                }
                else
                    CipherText += PlainText[i];
            }
            return CipherText;
        }

        public override string DecryptText(string CipherText)
        {
            string PlainText = string.Empty;
            int Index;
            for (int i = 0; i < CipherText.Length; i++)
            {
                if (char.IsLetter(CipherText[i]))
                {
                    Index = Key.IndexOf(char.ToLower(CipherText[i]));
                    Index = (Index - NumberOfShift) % 26;
                    Index = (Index < 0) ? Index + 26 : Index;
                    PlainText += (char.IsLower(CipherText[i]) ? (char)(Index + 97) : (char)(Index + 65));
                }
                else
                    PlainText += CipherText[i];
            }
            return PlainText;
        }
    }
}
