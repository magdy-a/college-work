﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Security_Algorithms
{
    class Columnar : Security_Algorithms
    {
        private string Key;

        public Columnar()
        {
            this.Key = "1234";
        }
        public Columnar(string key)
        {
            if (key.IndexOf(',') == -1)
                this.Key = key;
            else
            {
                this.Key = GetPureKey(key);
            }
        }

        public override string EncryptText(string PlainText)
        {
            string CipherText = string.Empty;
            double S = (double)PlainText.Length / Key.Length;
            int Size = (int)Math.Ceiling(S);
            char[,] Matrix = new char[Key.Length, Size];
            int k = 0;
            for (int i = 0; i < Size; i++)
            {
                for (int j = 0; j < Key.Length; j++)
                {
                    Matrix[j, i] = PlainText[k++];
                    if (k == PlainText.Length)
                        break;
                }
            }
            k = 0;
            int Column = 0;
            for (int i = 0; i < Key.Length; i++)
            {
                Column = Key.IndexOf((i+1).ToString());
                for (int j = 0; j < Size; j++)
                {
                    if (Matrix[Column, j] != '\0')
                    {
                        CipherText += Matrix[Column, j];
                        k++;
                    }
                    if (k == PlainText.Length)
                        break;
                }
            }
            return CipherText;
        }
        public override string DecryptText(string CipherText)
        {
            string PlainText = string.Empty;
            double S = (double)CipherText.Length / Key.Length;
            int Size = (int)Math.Ceiling(S);
            int NotComplete = Key.Length - (CipherText.Length % Key.Length);
            char[,] Matrix = new char[Key.Length, Size];
            int k = 0, Temp,Column;
            for (int i = 0; i < Key.Length; i++)
            {
                Column = Key.IndexOf((i + 1).ToString());
                if (Key.Length - Column <= NotComplete)
                    Temp = Size - 1;
                else
                    Temp = Size;
                for (int j = 0; j < Temp; j++)
                {
                    Matrix[Column, j] = CipherText[k++];
                    if (k == CipherText.Length)
                        break;
                }
            }
            k = 0;
            for (int i = 0; i < Size; i++)
            {
                for (int j = 0; j < Key.Length; j++)
                {
                    PlainText += Matrix[j, i];
                    k++;
                    if (k == CipherText.Length)
                        break;
                }
            }

            return PlainText;
        }

        private string GetPureKey(string Key)
        {
            string PureKey = string.Empty;
            for (int i = 0; i < Key.Length; i++)
            {
                if (Key[i] != ',')
                    PureKey += Key[i];
            }
            return PureKey;
        }
    }
}
