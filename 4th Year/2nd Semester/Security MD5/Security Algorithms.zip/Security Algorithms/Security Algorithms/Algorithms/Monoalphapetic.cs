﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Security_Algorithms
{
    class Monoalphapetic : Security_Algorithms
    {
        private string Key = "abcdefghijklmnopqrstuvwxyz";
        private string UsingKey;

        public Monoalphapetic()
        {
            this.UsingKey = "abcdefghijklmnopqrstuvwxyz";
        }
        public Monoalphapetic(string key)
        {
            this.UsingKey = key;
        }

        public override string EncryptText(string PlainText)
        {
            string CipherText = string.Empty;
            int Index;
            for (int i = 0; i < PlainText.Length; i++)
            {
                if (char.IsLetter(PlainText[i]))
                {
                    Index = Key.IndexOf(char.ToLower(PlainText[i]));
                    CipherText += (char.IsLower(PlainText[i]) ? UsingKey[Index] : char.ToUpper(UsingKey[Index]));
                }
                else
                    CipherText += PlainText[i];
            }
            return CipherText;
        }
        public override string DecryptText(string CipherText)
        {
            string PlainText = string.Empty;
            int Index;
            for (int i = 0; i < CipherText.Length; i++)
            {
                if (char.IsLetter(CipherText[i]))
                {
                    Index = UsingKey.IndexOf(char.ToLower(CipherText[i]));
                    PlainText += (char.IsLower(CipherText[i]) ? Key[Index] : char.ToUpper(Key[Index]));
                }
                else
                    PlainText += CipherText[i];
            }
            return PlainText;
        }
    }
}
