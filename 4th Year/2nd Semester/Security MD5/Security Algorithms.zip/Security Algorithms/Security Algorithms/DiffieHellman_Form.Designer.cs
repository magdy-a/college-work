﻿namespace Security_Algorithms
{
    partial class DiffieHellman_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.Q_TextBox = new System.Windows.Forms.TextBox();
            this.Alpha_TextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.UserA_X_TextBox = new System.Windows.Forms.TextBox();
            this.UserB_X_TextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.UserB_Y_TextBox = new System.Windows.Forms.TextBox();
            this.UserA_Y_TextBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.UserB_K_TextBox = new System.Windows.Forms.TextBox();
            this.UserA_K_TextBox = new System.Windows.Forms.TextBox();
            this.Go_Button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(24, 14);
            this.label1.TabIndex = 0;
            this.label1.Text = "Q :";
            // 
            // Q_TextBox
            // 
            this.Q_TextBox.Location = new System.Drawing.Point(61, 7);
            this.Q_TextBox.Name = "Q_TextBox";
            this.Q_TextBox.Size = new System.Drawing.Size(62, 20);
            this.Q_TextBox.TabIndex = 1;
            // 
            // Alpha_TextBox
            // 
            this.Alpha_TextBox.Location = new System.Drawing.Point(61, 36);
            this.Alpha_TextBox.Name = "Alpha_TextBox";
            this.Alpha_TextBox.Size = new System.Drawing.Size(62, 20);
            this.Alpha_TextBox.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(5, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 14);
            this.label2.TabIndex = 2;
            this.label2.Text = "Alpha :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(58, 81);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 18);
            this.label3.TabIndex = 4;
            this.label3.Text = "User A";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(152, 81);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 18);
            this.label4.TabIndex = 5;
            this.label4.Text = "User B";
            // 
            // UserA_X_TextBox
            // 
            this.UserA_X_TextBox.Location = new System.Drawing.Point(45, 117);
            this.UserA_X_TextBox.Name = "UserA_X_TextBox";
            this.UserA_X_TextBox.Size = new System.Drawing.Size(78, 20);
            this.UserA_X_TextBox.TabIndex = 6;
            // 
            // UserB_X_TextBox
            // 
            this.UserB_X_TextBox.Location = new System.Drawing.Point(141, 117);
            this.UserB_X_TextBox.Name = "UserB_X_TextBox";
            this.UserB_X_TextBox.Size = new System.Drawing.Size(78, 20);
            this.UserB_X_TextBox.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(11, 118);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(26, 16);
            this.label5.TabIndex = 8;
            this.label5.Text = "X :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(11, 153);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(26, 16);
            this.label6.TabIndex = 11;
            this.label6.Text = "Y :";
            // 
            // UserB_Y_TextBox
            // 
            this.UserB_Y_TextBox.Location = new System.Drawing.Point(141, 152);
            this.UserB_Y_TextBox.Name = "UserB_Y_TextBox";
            this.UserB_Y_TextBox.Size = new System.Drawing.Size(78, 20);
            this.UserB_Y_TextBox.TabIndex = 10;
            // 
            // UserA_Y_TextBox
            // 
            this.UserA_Y_TextBox.Location = new System.Drawing.Point(45, 152);
            this.UserA_Y_TextBox.Name = "UserA_Y_TextBox";
            this.UserA_Y_TextBox.Size = new System.Drawing.Size(78, 20);
            this.UserA_Y_TextBox.TabIndex = 9;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(11, 188);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(25, 16);
            this.label7.TabIndex = 14;
            this.label7.Text = "K :";
            // 
            // UserB_K_TextBox
            // 
            this.UserB_K_TextBox.Location = new System.Drawing.Point(141, 187);
            this.UserB_K_TextBox.Name = "UserB_K_TextBox";
            this.UserB_K_TextBox.Size = new System.Drawing.Size(78, 20);
            this.UserB_K_TextBox.TabIndex = 13;
            // 
            // UserA_K_TextBox
            // 
            this.UserA_K_TextBox.Location = new System.Drawing.Point(45, 187);
            this.UserA_K_TextBox.Name = "UserA_K_TextBox";
            this.UserA_K_TextBox.Size = new System.Drawing.Size(78, 20);
            this.UserA_K_TextBox.TabIndex = 12;
            // 
            // Go_Button
            // 
            this.Go_Button.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Go_Button.Location = new System.Drawing.Point(141, 9);
            this.Go_Button.Name = "Go_Button";
            this.Go_Button.Size = new System.Drawing.Size(78, 49);
            this.Go_Button.TabIndex = 15;
            this.Go_Button.Text = "Go";
            this.Go_Button.UseVisualStyleBackColor = true;
            this.Go_Button.Click += new System.EventHandler(this.Go_Button_Click);
            // 
            // DiffieHellman_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(229, 219);
            this.Controls.Add(this.Go_Button);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.UserB_K_TextBox);
            this.Controls.Add(this.UserA_K_TextBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.UserB_Y_TextBox);
            this.Controls.Add(this.UserA_Y_TextBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.UserB_X_TextBox);
            this.Controls.Add(this.UserA_X_TextBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Alpha_TextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Q_TextBox);
            this.Controls.Add(this.label1);
            this.Name = "DiffieHellman_Form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Diffie Hellman";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Q_TextBox;
        private System.Windows.Forms.TextBox Alpha_TextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox UserA_X_TextBox;
        private System.Windows.Forms.TextBox UserB_X_TextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox UserB_Y_TextBox;
        private System.Windows.Forms.TextBox UserA_Y_TextBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox UserB_K_TextBox;
        private System.Windows.Forms.TextBox UserA_K_TextBox;
        private System.Windows.Forms.Button Go_Button;
    }
}