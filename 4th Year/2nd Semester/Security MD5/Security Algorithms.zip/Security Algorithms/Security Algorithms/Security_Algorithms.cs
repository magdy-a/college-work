﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Security_Algorithms
{
    public abstract class Security_Algorithms
    {
        protected int Number_Of_Repeat;
        public abstract string EncryptText(string PlainText);
        public abstract string DecryptText(string CipherText);
    }
}
