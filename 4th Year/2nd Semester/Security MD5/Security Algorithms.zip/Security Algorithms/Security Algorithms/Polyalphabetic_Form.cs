﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Security_Algorithms
{
    public partial class Polyalphabetic_Form : Form
    {
        public Polyalphabetic_Form()
        {
            InitializeComponent();
            Kind_Of_Key_ComboBox.SelectedIndex = 0;
        }

        public string Key = string.Empty;
        private void Go_Button_Click(object sender, EventArgs e)
        {
            Key = Key_TextBox.Text;
            this.Close();
        }
        public string Get_Key()
        {
            return Key;
        }
        public Polyalphabetic_Key Get_Kind_Of_Key()
        {
            if (Kind_Of_Key_ComboBox.SelectedIndex == 0)
                return Polyalphabetic_Key.RepeatedKey;
            else
                return Polyalphabetic_Key.AutoKey;
        }
    }
}
