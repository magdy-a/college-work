﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Security_Algorithms
{
    public partial class RC4_Form : Form
    {
        public RC4_Form()
        {
            InitializeComponent();
        }
        public string Key = string.Empty;
        private void Go_Button_Click(object sender, EventArgs e)
        {
            if (Key_Word_TextBox.Text != string.Empty)
            {
                Key = Key_Word_TextBox.Text;
                this.Close();
            }
            else
                MessageBox.Show("Empty Key");
        }
        public string Get_Key()
        {
            return Key;
        }
    }
}
