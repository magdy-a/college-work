﻿namespace Security_Algorithms
{
    partial class HillCipher_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.Number_Key_ComboBox = new System.Windows.Forms.ComboBox();
            this.Generate_Button = new System.Windows.Forms.Button();
            this.Matrix_DataGridView = new System.Windows.Forms.DataGridView();
            this.Go_Button = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.Matrix_DataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Number :";
            // 
            // Number_Key_ComboBox
            // 
            this.Number_Key_ComboBox.FormattingEnabled = true;
            this.Number_Key_ComboBox.Items.AddRange(new object[] {
            "2",
            "3"});
            this.Number_Key_ComboBox.Location = new System.Drawing.Point(85, 12);
            this.Number_Key_ComboBox.Name = "Number_Key_ComboBox";
            this.Number_Key_ComboBox.Size = new System.Drawing.Size(86, 21);
            this.Number_Key_ComboBox.TabIndex = 1;
            // 
            // Generate_Button
            // 
            this.Generate_Button.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Generate_Button.Location = new System.Drawing.Point(191, 12);
            this.Generate_Button.Name = "Generate_Button";
            this.Generate_Button.Size = new System.Drawing.Size(75, 24);
            this.Generate_Button.TabIndex = 2;
            this.Generate_Button.Text = "Generate";
            this.Generate_Button.UseVisualStyleBackColor = true;
            this.Generate_Button.Click += new System.EventHandler(this.Generate_Button_Click);
            // 
            // Matrix_DataGridView
            // 
            this.Matrix_DataGridView.AllowUserToAddRows = false;
            this.Matrix_DataGridView.AllowUserToDeleteRows = false;
            this.Matrix_DataGridView.AllowUserToResizeColumns = false;
            this.Matrix_DataGridView.AllowUserToResizeRows = false;
            this.Matrix_DataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Matrix_DataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Matrix_DataGridView.ColumnHeadersVisible = false;
            this.Matrix_DataGridView.Location = new System.Drawing.Point(16, 39);
            this.Matrix_DataGridView.Name = "Matrix_DataGridView";
            this.Matrix_DataGridView.RowHeadersVisible = false;
            this.Matrix_DataGridView.Size = new System.Drawing.Size(155, 77);
            this.Matrix_DataGridView.TabIndex = 3;
            this.Matrix_DataGridView.Visible = false;
            // 
            // Go_Button
            // 
            this.Go_Button.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Go_Button.Location = new System.Drawing.Point(191, 56);
            this.Go_Button.Name = "Go_Button";
            this.Go_Button.Size = new System.Drawing.Size(75, 48);
            this.Go_Button.TabIndex = 4;
            this.Go_Button.Text = "Go";
            this.Go_Button.UseVisualStyleBackColor = true;
            this.Go_Button.Visible = false;
            this.Go_Button.Click += new System.EventHandler(this.Go_Button_Click);
            // 
            // HillCipher_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(278, 128);
            this.Controls.Add(this.Go_Button);
            this.Controls.Add(this.Matrix_DataGridView);
            this.Controls.Add(this.Generate_Button);
            this.Controls.Add(this.Number_Key_ComboBox);
            this.Controls.Add(this.label1);
            this.Name = "HillCipher_Form";
            this.Text = "HillCipher Algorithm";
            ((System.ComponentModel.ISupportInitialize)(this.Matrix_DataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox Number_Key_ComboBox;
        private System.Windows.Forms.Button Generate_Button;
        private System.Windows.Forms.DataGridView Matrix_DataGridView;
        private System.Windows.Forms.Button Go_Button;
    }
}