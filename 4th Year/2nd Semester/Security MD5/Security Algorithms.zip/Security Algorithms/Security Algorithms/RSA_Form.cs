﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Security_Algorithms
{
    public partial class RSA_Form : Form
    {
        public RSA_Form()
        {
            InitializeComponent();
            PT_TextBox.Text = "88";
            P_TextBox.Text = "11";
            Q_TextBox.Text = "17";
            E_TextBox.Text = "7";
        }
        struct Row
        {
            public int Q, A1, A2, A3, B1, B2, B3;
            public Row(int q, int a1, int a2, int a3, int b1, int b2, int b3)
            {
                this.Q = q;
                this.A1 = a1;
                this.A2 = a2;
                this.A3 = a3;
                this.B1 = b1;
                this.B2 = b2;
                this.B3 = b3;
            }
        }
        private void Encrypt_Button_Click(object sender, EventArgs e)
        {
            int PT, CT, P, Q, E, D, N, Totient_N;

            PT = int.Parse(PT_TextBox.Text);
            P = int.Parse(P_TextBox.Text);
            Q = int.Parse(Q_TextBox.Text);

            N = P * Q;
            Totient_N = (P - 1) * (Q - 1);
            N_TextBox.Text = N.ToString();
            TotientN_TextBox.Text = Totient_N.ToString();

            E = int.Parse(E_TextBox.Text);
            int Gcd = GCD(Totient_N, E);
            if (Gcd != 1)
                MessageBox.Show("GCD for (e) and (Totient) Not equal (1)");
            else
            {
                CT = CalculatePower(PT, E, N);
                CT_TextBox.Text = CT.ToString();

                D = MultiplicativeInverse(E, Totient_N);
                if (D != -1)
                    D_TextBox.Text = D.ToString();
                else
                    MessageBox.Show(string.Format("Program Can't Calculate Multiplicative Inverse for (D = {0})", D));
            }
        }
        private void Decrypt_Button_Click(object sender, EventArgs e)
        {
            int PT, CT, P, Q, E, D, N, Totient_N;

            CT = int.Parse(CT_TextBox.Text);
            P = int.Parse(P_TextBox.Text);
            Q = int.Parse(Q_TextBox.Text);

            N = P * Q;
            Totient_N = (P - 1) * (Q - 1);
            N_TextBox.Text = N.ToString();
            TotientN_TextBox.Text = Totient_N.ToString();

            D = int.Parse(D_TextBox.Text);
            PT = CalculatePower(CT, D, N);
            PT_TextBox.Text = PT.ToString();

            E = MultiplicativeInverse(D, Totient_N);
            if (E != -1)
                E_TextBox.Text = E.ToString();
            else
                MessageBox.Show(string.Format("Program Can't Calculate Multiplicative Inverse for (E = {0})", E));
        }

        private int CalculatePower(int Base, int Power, int other)
        {
            int Result = 1;
            List<int> P = Powers(Power);
            for (int i = 0; i < P.Count; i++)
            {
                Result *= ((int)Math.Pow((double)Base, P[i])) % other;
            }
            Result = Result % other;

            return Result;
        }
        private List<int> Powers(int Number)
        {
            List<int> Result = new List<int>();
            int sum = 0;
            int temp = 1;
            while (temp + sum <= Number)
            {
                Result.Add(temp);
                sum += temp;
                temp *= 2;
            }
            int index = Result.Count - 1;
            while (sum != Number && index >= 0)
            {
                if (Result[index] + sum <= Number)
                {
                    Result.Add(Result[index]);
                    sum += Result[index];
                }
                else
                    index--;
            }
            return Result;
        }
        private int GCD(int a, int b)
        {
            if (b == 0)
                return a;
            return GCD(b, a % b);
        }
        private int MultiplicativeInverse(int Number, int Base)
        {
            int Result = -1;
            List<Row> Array = new List<Row>();
            Row T = new Row(0, 1, 0, Base, 0, 1, Number);
            Array.Add(T);
            int Cnt=1;
            for (int i = 1; i <= Cnt; i++)
			{
                T.Q = Array[i - 1].A3 / Array[i - 1].B3;
                T.B3 = Array[i - 1].A3 % Array[i - 1].B3;
                T.A1 = Array[i - 1].B1;
                T.A2 = Array[i - 1].B2;
                T.A3 = Array[i - 1].B3;
                T.B1 = Array[i - 1].A1 - (T.Q * Array[i - 1].B1);
                T.B2 = Array[i - 1].A2 - (T.Q * Array[i - 1].B2);

                if (T.B3 == 0)
                {
                    Result = -1;
                }
                else if (T.B3 == 1)
                {
                    Result = T.B2;
                    if (Result < 0)
                    {
                        Result = Result - ((int)Math.Floor((double)Result / Base) * Base);
                    }
                    else
                        Result = Result % Base;
                }
                else
                {
                    Array.Add(T);
                    Cnt++;
                }
			}
            return Result;
        }

    }
}
