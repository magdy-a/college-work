﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Security_Algorithms
{
    public partial class Ceaser_Cipher_Form : Form
    {
        public Ceaser_Cipher_Form()
        {
            InitializeComponent();
        }
        public int Number_Of_Shift;
        private void Go_Button_Click(object sender, EventArgs e)
        {
            Number_Of_Shift = int.Parse(Number_Of_Shift_TextBox.Text);
            this.Close();
        }
        public int Get_Number_Of_Shift()
        {
            return Number_Of_Shift;
        }
    }
}
