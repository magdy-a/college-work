﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Security_Algorithms
{
    public partial class RailFence_Form : Form
    {
        public RailFence_Form()
        {
            InitializeComponent();
        }
        public int Depth;
        private void Go_Button_Click(object sender, EventArgs e)
        {
            Depth = int.Parse(Depth_TextBox.Text);
            this.Close();
        }
        public int Get_Depth()
        {
            return Depth;
        }
    }
}
