﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Security_Algorithms
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            //PlainText_TextBox.Text = "qsonctmm";
            //ListOfAlgorithms_ComboBox.SelectedIndex = 0;
            //PlainText_TextBox.Text = "1234abcd"; // DES
            PlainText_TextBox.Text = "0123456789ABCDEFFEDCBA9876543210"; // AES
            //PlainText_TextBox.Text = "3243f6a8885a308d313198a2e0370734";
        }

        #region Form Properties
        Ceaser_Cipher_Form Ceaser_Cipher_Form1;
        Monoalphapetic_Form Monoalphapetic_Form1;
        Polyalphabetic_Form Polyalphabetic_Form1;
        PleyFair_Form PleyFair_Form1;
        RailFence_Form RailFence_Form1;
        Columnar_Form Columnar_Form1;
        HillCipher_Form HillCipher_Form1;
        DES_Form DES_Form1;
        TripleDes_Form TripleDes_Form1;
        AES_Form AES_Form1;
        RC4_Form RC4_Form1;
        RSA_Form RSA_Form1;
        DiffieHellman_Form DiffieHellman_Form1;
        MultiplicativeInverse_Form MultiplicativeInverse_Form1;
        #endregion

        private enum KindOfAlgorithm { CeaserCipher, Monoalphapetic, Polyalphabetic, PleyFair, RailFence, Columnar, HillCipher, DES, TripleDes, AES, RC4, MD5, RSA, DiffieHellman, MultiplicativeInverse, Error };
        private KindOfAlgorithm GetKindOfAlgorithm()
        {
            switch (ListOfAlgorithms_ComboBox.SelectedIndex)
            {
                case 0:
                    return KindOfAlgorithm.CeaserCipher;
                case 1:
                    return KindOfAlgorithm.Monoalphapetic;
                case 2:
                    return KindOfAlgorithm.Polyalphabetic;
                case 3:
                    return KindOfAlgorithm.PleyFair;
                case 4:
                    return KindOfAlgorithm.RailFence;
                case 5:
                    return KindOfAlgorithm.Columnar;
                case 6:
                    return KindOfAlgorithm.HillCipher;
                case 7:
                    return KindOfAlgorithm.DES;
                case 8:
                    return KindOfAlgorithm.TripleDes;
                case 9:
                    return KindOfAlgorithm.AES;
                case 10:
                    return KindOfAlgorithm.RC4;
                case 11:
                    return KindOfAlgorithm.MD5;
                case 12:
                    return KindOfAlgorithm.RSA;
                case 13:
                    return KindOfAlgorithm.DiffieHellman;
                case 14:
                    return KindOfAlgorithm.MultiplicativeInverse;
                default:
                    return KindOfAlgorithm.Error;
            }
        }

        /// <summary>
        /// Intialize Form and Show It    
        /// </summary>
        private void ListOfAlgorithms_ComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            KindOfAlgorithm Algorithm = GetKindOfAlgorithm();
            switch (Algorithm)
            {
                case KindOfAlgorithm.CeaserCipher:
                    Ceaser_Cipher_Form1 = new Ceaser_Cipher_Form();
                    Ceaser_Cipher_Form1.Show();
                    break;
                case KindOfAlgorithm.Monoalphapetic:
                    Monoalphapetic_Form1 = new Monoalphapetic_Form();
                    Monoalphapetic_Form1.Show();
                    break;
                case KindOfAlgorithm.Polyalphabetic:
                    Polyalphabetic_Form1 = new Polyalphabetic_Form();
                    Polyalphabetic_Form1.Show();
                    break;
                case KindOfAlgorithm.PleyFair:
                    PleyFair_Form1 = new PleyFair_Form();
                    PleyFair_Form1.Show();
                    break;
                case KindOfAlgorithm.RailFence:
                    RailFence_Form1 = new RailFence_Form();
                    RailFence_Form1.Show();
                    break;
                case KindOfAlgorithm.Columnar:
                    Columnar_Form1 = new Columnar_Form();
                    Columnar_Form1.Show();
                    break;
                case KindOfAlgorithm.HillCipher:
                    HillCipher_Form1 = new HillCipher_Form();
                    HillCipher_Form1.Show();
                    break;
                case KindOfAlgorithm.DES:
                    DES_Form1 = new DES_Form();
                    DES_Form1.Show();
                    break;
                case KindOfAlgorithm.TripleDes:
                    TripleDes_Form1 = new TripleDes_Form();
                    TripleDes_Form1.Show();
                    break;
                case KindOfAlgorithm.AES:
                    AES_Form1 = new AES_Form();
                    AES_Form1.Show();
                    break;
                case KindOfAlgorithm.RC4:
                    RC4_Form1 = new RC4_Form();
                    RC4_Form1.Show();
                    break;
                case KindOfAlgorithm.MD5:
                    break;
                case KindOfAlgorithm.RSA:
                    RSA_Form1 = new RSA_Form();
                    RSA_Form1.Show();
                    break;
                case KindOfAlgorithm.DiffieHellman:
                    this.Hide();
                    DiffieHellman_Form1 = new DiffieHellman_Form();
                    DiffieHellman_Form1.ShowDialog();
                    this.Show();
                    break;
                case KindOfAlgorithm.MultiplicativeInverse:
                    this.Hide();
                    MultiplicativeInverse_Form1 = new MultiplicativeInverse_Form();
                    MultiplicativeInverse_Form1.ShowDialog();
                    this.Show();
                    break;
                default:
                    MessageBox.Show("Error to show Form");
                    break;
            }
        }


        private void Encrypt_Button_Click(object sender, EventArgs e)
        {
            KindOfAlgorithm Algorithm = GetKindOfAlgorithm();
            string PlainText = PlainText_TextBox.Text;
            PlainText = PlainText.Replace(" ", string.Empty);
            PlainText = PlainText.ToLower();
            PlainText_TextBox.Text = PlainText;
            string CipherText = string.Empty;
            switch (Algorithm)
            {
                #region Ceaser Cipher
                case KindOfAlgorithm.CeaserCipher:
                    Ceaser_Cipher CeaserCipher = new Ceaser_Cipher(Ceaser_Cipher_Form1.Get_Number_Of_Shift());
                    CipherText = CeaserCipher.EncryptText(PlainText);
                    CipherText_TextBox.Text = CipherText;
                    break;
                #endregion
                #region Monoalphapetic
                case KindOfAlgorithm.Monoalphapetic:
                    //Monoalphapetic monoalphapetic = new Monoalphapetic("xyzabcdefghijklmnopqrstuvw");
                    Monoalphapetic monoalphapetic = new Monoalphapetic(Monoalphapetic_Form1.Get_Key());
                    CipherText = monoalphapetic.EncryptText(PlainText);
                    CipherText_TextBox.Text = CipherText;
                    break;
                #endregion
                #region Polyalphabetic
                case KindOfAlgorithm.Polyalphabetic:
                    Polyalphabetic polyalphabetic = new Polyalphabetic(Polyalphabetic_Form1.Get_Key(), Polyalphabetic_Form1.Get_Kind_Of_Key());
                    CipherText = polyalphabetic.EncryptText(PlainText);
                    CipherText_TextBox.Text = CipherText;
                    break;
                #endregion
                #region Pley Fair
                case KindOfAlgorithm.PleyFair:
                    Pley_Fair PleyFair = new Pley_Fair(PleyFair_Form1.Get_Key_Word());
                    CipherText_TextBox.Text = PleyFair.EncryptText(PlainText);
                    break;
                #endregion
                #region RailFence
                case KindOfAlgorithm.RailFence:
                    Rail_Fence RailFence = new Rail_Fence(RailFence_Form1.Get_Depth());
                    CipherText_TextBox.Text = RailFence.EncryptText(PlainText);
                    break;
                #endregion
                #region Columnar
                case KindOfAlgorithm.Columnar:
                    Columnar columnar = new Columnar(Columnar_Form1.Get_Key());
                    CipherText_TextBox.Text = columnar.EncryptText(PlainText);
                    break;
                #endregion
                #region Hill Cipher
                case KindOfAlgorithm.HillCipher:
                    Hill_Cipher hill_cipher = new Hill_Cipher(HillCipher_Form1.Get_Number_Key(), HillCipher_Form1.Get_Matrix());
                    CipherText_TextBox.Text = hill_cipher.EncryptText(PlainText);
                    break;
                #endregion
                #region DES
                case KindOfAlgorithm.DES:
                    DES Des = new DES(DES_Form1.Get_Key(),DES_Form1.Get_KindOfKey());
                    CipherText_TextBox.Text = Des.EncryptText(PlainText);
                    break;
                #endregion
                #region TripleDes
                case KindOfAlgorithm.TripleDes:
                    TripleDes tripleDes = new TripleDes(TripleDes_Form1.Get_FirstKey(), TripleDes_Form1.Get_SecondKey(), TripleDes_Form1.Get_KindOfKey());
                    CipherText_TextBox.Text = tripleDes.EncryptText(PlainText);
                    break;
                #endregion
                #region AES
                case KindOfAlgorithm.AES:
                    AES Aes = new AES(AES_Form1.Get_Key(), AES_Form1.Get_KindOfKey());
                    CipherText_TextBox.Text = Aes.EncryptText(PlainText);
                    break;
                #endregion
                #region RC4
                case KindOfAlgorithm.RC4:
                    RC4 Rc4 = new RC4(RC4_Form1.Get_Key());
                    CipherText_TextBox.Text = Rc4.EncryptText(PlainText);
                    break;
                #endregion
                #region MD5
                case KindOfAlgorithm.MD5:
                    MD5 Md5 = new MD5();
                    CipherText_TextBox.Text = Md5.EncryptText(PlainText);
                    break;
                #endregion
                #region RSA
                case KindOfAlgorithm.RSA:
                    CipherText_TextBox.Text = "Not Working for this Algorithm .. !";
                    break;
                #endregion
                #region DiffieHellman
                case KindOfAlgorithm.DiffieHellman:
                    CipherText_TextBox.Text = "Not Working for this Algorithm .. !";
                    break;
                #endregion
                #region MultiplicativeInverse
                case KindOfAlgorithm.MultiplicativeInverse:
                     CipherText_TextBox.Text = "Not Working for this Algorithm .. !";
                    break;
                #endregion
                default:
                    CipherText_TextBox.Text = "Error";
                    break;
            }
        }
        private void Decrypt_Button_Click(object sender, EventArgs e)
        {
            KindOfAlgorithm Algorithm = GetKindOfAlgorithm();
            string PlainText = string.Empty;
            string CipherText = CipherText_TextBox.Text;
            CipherText = CipherText.Replace(" ", string.Empty);
            CipherText = CipherText.ToLower();
            CipherText_TextBox.Text = CipherText;
            switch (Algorithm)
            {
                #region Ceaser Cipher
                case KindOfAlgorithm.CeaserCipher:
                    Ceaser_Cipher CeaserCipher = new Ceaser_Cipher(Ceaser_Cipher_Form1.Get_Number_Of_Shift());
                    PlainText = CeaserCipher.DecryptText(CipherText);
                    PlainText_TextBox.Text = PlainText;
                    break;
                #endregion
                #region Monoalphapetic
                case KindOfAlgorithm.Monoalphapetic:
                    Monoalphapetic monoalphapetic = new Monoalphapetic(Monoalphapetic_Form1.Get_Key());
                    PlainText = monoalphapetic.DecryptText(CipherText);
                    PlainText_TextBox.Text = PlainText;
                    break;
                #endregion
                #region Polyalphabetic
                case KindOfAlgorithm.Polyalphabetic:
                    Polyalphabetic polyalphabetic = new Polyalphabetic(Polyalphabetic_Form1.Get_Key(), Polyalphabetic_Form1.Get_Kind_Of_Key());
                    PlainText = polyalphabetic.DecryptText(CipherText);
                    PlainText_TextBox.Text = PlainText;
                    break;
                #endregion
                #region Pley Fair
                case KindOfAlgorithm.PleyFair:
                    Pley_Fair PleyFair = new Pley_Fair(PleyFair_Form1.Get_Key_Word());
                    PlainText_TextBox.Text = PleyFair.DecryptText(CipherText);
                    break;
                #endregion
                #region RailFence
                case KindOfAlgorithm.RailFence:
                    Rail_Fence RailFence = new Rail_Fence(RailFence_Form1.Get_Depth());
                    PlainText_TextBox.Text = RailFence.DecryptText(CipherText);
                    break;
                #endregion
                #region Columnar
                case KindOfAlgorithm.Columnar:
                    Columnar columnar = new Columnar(Columnar_Form1.Get_Key());
                    PlainText_TextBox.Text = columnar.DecryptText(CipherText);
                    break;
                #endregion
                #region Hill Cipher
                case KindOfAlgorithm.HillCipher:
                    Hill_Cipher hill_cipher = new Hill_Cipher(HillCipher_Form1.Get_Number_Key(), HillCipher_Form1.Get_Matrix());
                    PlainText_TextBox.Text = hill_cipher.DecryptText(CipherText);
                    break;
                #endregion
                #region DES
                case KindOfAlgorithm.DES:
                    DES Des = new DES(DES_Form1.Get_Key(),DES_Form1.Get_KindOfKey());
                    PlainText_TextBox.Text = Des.DecryptText(CipherText);
                    break;
                #endregion
                #region TripleDes
                case KindOfAlgorithm.TripleDes:
                    TripleDes tripleDes = new TripleDes(TripleDes_Form1.Get_FirstKey(), TripleDes_Form1.Get_SecondKey(), TripleDes_Form1.Get_KindOfKey());
                    PlainText_TextBox.Text = tripleDes.DecryptText(CipherText);
                    break;
                #endregion
                #region AES
                    AES Aes = new AES(AES_Form1.Get_Key(), AES_Form1.Get_KindOfKey());
                    PlainText_TextBox.Text = Aes.DecryptText(CipherText);
                    break;
                #endregion
                #region RC4
                case KindOfAlgorithm.RC4:
                    RC4 Rc4 = new RC4(RC4_Form1.Get_Key());
                    PlainText_TextBox.Text = Rc4.DecryptText(CipherText);
                    break;
                #endregion
                #region MD5
                case KindOfAlgorithm.MD5:
                    MD5 Md5 = new MD5();
                    PlainText_TextBox.Text = Md5.DecryptText(CipherText);
                    break;
                #endregion
                #region RSA
                case KindOfAlgorithm.RSA:
                    PlainText_TextBox.Text = "Not Working for this Algorithm .. !";
                    break;
                #endregion
                #region DiffieHellman
                case KindOfAlgorithm.DiffieHellman:
                    PlainText_TextBox.Text = "Not Working for this Algorithm .. !";
                    break;
                #endregion
                #region MultiplicativeInverse
                case KindOfAlgorithm.MultiplicativeInverse:
                    PlainText_TextBox.Text = "Not Working for this Algorithm .. !";
                    break;
                #endregion
                default:
                    PlainText_TextBox.Text = "Error";
                    break;
            }
        }

    }
}