﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Security_Algorithms
{
    public partial class Columnar_Form : Form
    {
        public Columnar_Form()
        {
            InitializeComponent();
        }
        public string Key = string.Empty;
        private void Go_Button_Click(object sender, EventArgs e)
        {
                Key = Key_TextBox.Text;
                this.Close();
        }
        public string Get_Key()
        {
            return Key;
        }
    }
}
