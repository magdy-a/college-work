﻿namespace Security_Algorithms
{
    partial class MultiplicativeInverse_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.Number_TextBox = new System.Windows.Forms.TextBox();
            this.Base_TextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.GO_Button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Number : ";
            // 
            // Number_TextBox
            // 
            this.Number_TextBox.Location = new System.Drawing.Point(98, 37);
            this.Number_TextBox.Name = "Number_TextBox";
            this.Number_TextBox.Size = new System.Drawing.Size(66, 20);
            this.Number_TextBox.TabIndex = 3;
            // 
            // Base_TextBox
            // 
            this.Base_TextBox.Location = new System.Drawing.Point(98, 8);
            this.Base_TextBox.Name = "Base_TextBox";
            this.Base_TextBox.Size = new System.Drawing.Size(66, 20);
            this.Base_TextBox.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(30, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "Base : ";
            // 
            // GO_Button
            // 
            this.GO_Button.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GO_Button.Location = new System.Drawing.Point(184, 9);
            this.GO_Button.Name = "GO_Button";
            this.GO_Button.Size = new System.Drawing.Size(63, 48);
            this.GO_Button.TabIndex = 4;
            this.GO_Button.Text = "Go";
            this.GO_Button.UseVisualStyleBackColor = true;
            this.GO_Button.Click += new System.EventHandler(this.GO_Button_Click);
            // 
            // MultiplicativeInverse_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(256, 69);
            this.Controls.Add(this.GO_Button);
            this.Controls.Add(this.Base_TextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Number_TextBox);
            this.Controls.Add(this.label1);
            this.Name = "MultiplicativeInverse_Form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Multiplicative Inverse";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Number_TextBox;
        private System.Windows.Forms.TextBox Base_TextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button GO_Button;
    }
}