﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Security_Algorithms
{
    public partial class TripleDes_Form : Form
    {
        public TripleDes_Form()
        {
            InitializeComponent();
        }
        public string FirstKey = string.Empty;
        public string SecondKey = string.Empty;

        private void Go_Button_Click(object sender, EventArgs e)
        {
            FirstKey = FirstKey_TextBox.Text;
            SecondKey = SecondKey_TextBox.Text;
            this.Close();
        }
        public string Get_FirstKey()
        {
            return FirstKey;
        }
        public string Get_SecondKey()
        {
            return SecondKey;
        }
        public bool Get_KindOfKey()
        {
            // 0 -> Text -> True
            // 1 -> Hex -> False
            if (KindOfKey_ComboBox.SelectedIndex == 1)
                return false;
            return true;
        }

    }
}
