﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Security_Algorithms
{
    public partial class AES_Form : Form
    {
        public AES_Form()
        {
            InitializeComponent();
            //Key_TextBox.Text = "FEDCBA9876543210FEDCBA9876543210";
            Key_TextBox.Text = "2b7e151628aed2a6abf7158809cf4f3c";
            KindOfKey_ComboBox.SelectedIndex = 0;
        }
        public string Key = string.Empty;
        private void Go_Button_Click(object sender, EventArgs e)
        {
            Key = Key_TextBox.Text;
            this.Close();
        }
        public string Get_Key()
        {
            return Key;
        }
        public bool Get_KindOfKey()
        {
            // 0 -> Text -> True
            // 1 -> Hex -> False
            if (KindOfKey_ComboBox.SelectedIndex == 1)
                return false;
            return true;
        }
    }
}
