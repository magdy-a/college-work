﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Security_Algorithms
{
    public partial class HillCipher_Form : Form
    {
        public HillCipher_Form()
        {
            InitializeComponent();
            Number_Key_ComboBox.SelectedIndex = 0;
        }

        private int Number_Matrix;
        private int[,] Matrix;

        private void Generate_Button_Click(object sender, EventArgs e)
        {
            Number_Matrix = int.Parse(Number_Key_ComboBox.Text);

            Matrix_DataGridView.Rows.Clear();
            Matrix_DataGridView.Columns.Clear();
            for (int i = 0; i < Number_Matrix; i++)
            {
                Matrix_DataGridView.Columns.Add(i.ToString(), "");
            }
            Matrix_DataGridView.Rows.Add(Number_Matrix);

            Matrix_DataGridView.Visible = true;
            Go_Button.Visible = true;
        }
        private void Go_Button_Click(object sender, EventArgs e)
        {
            string temp = string.Empty;
            Matrix = new int[Number_Matrix, Number_Matrix];
            for (int i = 0; i < Number_Matrix; i++)
            {
                for (int j = 0; j < Number_Matrix; j++)
                {
                    Matrix[i, j] = int.Parse(Matrix_DataGridView[j, i].Value.ToString());
                    temp += Matrix[i, j].ToString() + "\n";
                }
            }
            MessageBox.Show(temp);
            this.Close();
        }

        public int Get_Number_Key()
        {
            return this.Number_Matrix;
        }
        public int[,] Get_Matrix()
        {
            return Matrix;
        }
    }
}
