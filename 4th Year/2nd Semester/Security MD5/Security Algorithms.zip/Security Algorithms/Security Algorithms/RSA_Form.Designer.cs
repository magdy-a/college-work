﻿namespace Security_Algorithms
{
    partial class RSA_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.PT_TextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.P_TextBox = new System.Windows.Forms.TextBox();
            this.Q_TextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.E_TextBox = new System.Windows.Forms.TextBox();
            this.D_TextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Encrypt_Button = new System.Windows.Forms.Button();
            this.Decrypt_Button = new System.Windows.Forms.Button();
            this.CT_TextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.TotientN_TextBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.N_TextBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(7, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "PT :";
            // 
            // PT_TextBox
            // 
            this.PT_TextBox.Location = new System.Drawing.Point(45, 12);
            this.PT_TextBox.Name = "PT_TextBox";
            this.PT_TextBox.Size = new System.Drawing.Size(55, 20);
            this.PT_TextBox.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(14, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(25, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "P :";
            // 
            // P_TextBox
            // 
            this.P_TextBox.Location = new System.Drawing.Point(45, 45);
            this.P_TextBox.Name = "P_TextBox";
            this.P_TextBox.Size = new System.Drawing.Size(55, 20);
            this.P_TextBox.TabIndex = 3;
            // 
            // Q_TextBox
            // 
            this.Q_TextBox.Location = new System.Drawing.Point(150, 45);
            this.Q_TextBox.Name = "Q_TextBox";
            this.Q_TextBox.Size = new System.Drawing.Size(55, 20);
            this.Q_TextBox.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(118, 46);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(26, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "Q :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(14, 79);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(24, 16);
            this.label4.TabIndex = 6;
            this.label4.Text = "E :";
            // 
            // E_TextBox
            // 
            this.E_TextBox.Location = new System.Drawing.Point(45, 79);
            this.E_TextBox.Name = "E_TextBox";
            this.E_TextBox.Size = new System.Drawing.Size(55, 20);
            this.E_TextBox.TabIndex = 7;
            // 
            // D_TextBox
            // 
            this.D_TextBox.Location = new System.Drawing.Point(150, 79);
            this.D_TextBox.Name = "D_TextBox";
            this.D_TextBox.Size = new System.Drawing.Size(55, 20);
            this.D_TextBox.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(120, 79);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(26, 16);
            this.label5.TabIndex = 8;
            this.label5.Text = "D :";
            // 
            // Encrypt_Button
            // 
            this.Encrypt_Button.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Encrypt_Button.Location = new System.Drawing.Point(17, 141);
            this.Encrypt_Button.Name = "Encrypt_Button";
            this.Encrypt_Button.Size = new System.Drawing.Size(83, 32);
            this.Encrypt_Button.TabIndex = 10;
            this.Encrypt_Button.Text = "Encrypt";
            this.Encrypt_Button.UseVisualStyleBackColor = true;
            this.Encrypt_Button.Click += new System.EventHandler(this.Encrypt_Button_Click);
            // 
            // Decrypt_Button
            // 
            this.Decrypt_Button.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Decrypt_Button.Location = new System.Drawing.Point(121, 140);
            this.Decrypt_Button.Name = "Decrypt_Button";
            this.Decrypt_Button.Size = new System.Drawing.Size(84, 33);
            this.Decrypt_Button.TabIndex = 11;
            this.Decrypt_Button.Text = "Decrypt";
            this.Decrypt_Button.UseVisualStyleBackColor = true;
            this.Decrypt_Button.Click += new System.EventHandler(this.Decrypt_Button_Click);
            // 
            // CT_TextBox
            // 
            this.CT_TextBox.Location = new System.Drawing.Point(150, 13);
            this.CT_TextBox.Name = "CT_TextBox";
            this.CT_TextBox.Size = new System.Drawing.Size(55, 20);
            this.CT_TextBox.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(112, 14);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(32, 16);
            this.label6.TabIndex = 12;
            this.label6.Text = "CT :";
            // 
            // TotientN_TextBox
            // 
            this.TotientN_TextBox.Location = new System.Drawing.Point(150, 108);
            this.TotientN_TextBox.Name = "TotientN_TextBox";
            this.TotientN_TextBox.Size = new System.Drawing.Size(55, 20);
            this.TotientN_TextBox.TabIndex = 17;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(109, 109);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 16);
            this.label7.TabIndex = 16;
            this.label7.Text = "(N) :";
            // 
            // N_TextBox
            // 
            this.N_TextBox.Location = new System.Drawing.Point(45, 108);
            this.N_TextBox.Name = "N_TextBox";
            this.N_TextBox.Size = new System.Drawing.Size(55, 20);
            this.N_TextBox.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(14, 108);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(25, 16);
            this.label8.TabIndex = 14;
            this.label8.Text = "N :";
            // 
            // RSA_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(217, 184);
            this.Controls.Add(this.TotientN_TextBox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.N_TextBox);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.CT_TextBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Decrypt_Button);
            this.Controls.Add(this.Encrypt_Button);
            this.Controls.Add(this.D_TextBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.E_TextBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Q_TextBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.P_TextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.PT_TextBox);
            this.Controls.Add(this.label1);
            this.Name = "RSA_Form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RSA Algorithm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox PT_TextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox P_TextBox;
        private System.Windows.Forms.TextBox Q_TextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox E_TextBox;
        private System.Windows.Forms.TextBox D_TextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button Encrypt_Button;
        private System.Windows.Forms.Button Decrypt_Button;
        private System.Windows.Forms.TextBox CT_TextBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox TotientN_TextBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox N_TextBox;
        private System.Windows.Forms.Label label8;
    }
}