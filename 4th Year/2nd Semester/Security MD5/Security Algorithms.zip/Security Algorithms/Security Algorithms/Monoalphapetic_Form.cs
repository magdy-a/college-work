﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Security_Algorithms
{
    public partial class Monoalphapetic_Form : Form
    {
        public Monoalphapetic_Form()
        {
            InitializeComponent();
        }
        public string Key=string.Empty;
        private void Go_Button_Click(object sender, EventArgs e)
        {
            if (Key_TextBox.Text.Length == 26)
            {
                Key = Key_TextBox.Text;
                this.Close();
            }
            else
                MessageBox.Show("Error , Length of Key Small Than 26");
        }
        public string Get_Key()
        {
            return Key;
        }
    }
}
