﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Security_Algorithms
{
    public partial class MultiplicativeInverse_Form : Form
    {
        public MultiplicativeInverse_Form()
        {
            InitializeComponent();
        }
        struct Row
        {
            public int Q, A1, A2, A3, B1, B2, B3;
            public Row(int q, int a1, int a2, int a3, int b1, int b2, int b3)
            {
                this.Q = q;
                this.A1 = a1;
                this.A2 = a2;
                this.A3 = a3;
                this.B1 = b1;
                this.B2 = b2;
                this.B3 = b3;
            }
        }
        private void GO_Button_Click(object sender, EventArgs e)
        {
            if (Number_TextBox.Text != "" && Base_TextBox.Text != "")
            {
                int Number = int.Parse(Number_TextBox.Text);
                int Base = int.Parse(Base_TextBox.Text);
                int Result = MultiplicativeInverse(Number, Base);
                if (Result != -1)
                    MessageBox.Show(string.Format("Result = {0}", Result));
                else
                    MessageBox.Show(string.Format("Program Can't Calculate Multiplicative Inverse"));
            }
            else
                MessageBox.Show("Some Input Is Empty ... !!!");
        }
        private int MultiplicativeInverse(int Number, int Base)
        {
            int Result = -1;
            List<Row> Array = new List<Row>();
            Row T = new Row(0, 1, 0, Base, 0, 1, Number);
            Array.Add(T);
            int Cnt = 1;
            for (int i = 1; i <= Cnt; i++)
            {
                T.Q = Array[i - 1].A3 / Array[i - 1].B3;
                T.B3 = Array[i - 1].A3 % Array[i - 1].B3;
                T.A1 = Array[i - 1].B1;
                T.A2 = Array[i - 1].B2;
                T.A3 = Array[i - 1].B3;
                T.B1 = Array[i - 1].A1 - (T.Q * Array[i - 1].B1);
                T.B2 = Array[i - 1].A2 - (T.Q * Array[i - 1].B2);

                if (T.B3 == 0)
                {
                    Result = -1;
                }
                else if (T.B3 == 1)
                {
                    Result = T.B2;
                    if (Result < 0)
                    {
                        Result = Result - ((int)Math.Floor((double)Result / Base) * Base);
                    }
                    else
                        Result = Result % Base;
                }
                else
                {
                    Array.Add(T);
                    Cnt++;
                }
            }
            return Result;
        }
    }
}
