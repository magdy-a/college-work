
#ifndef BOARD_H
#define BOARD_H

#include "Move.h"
	
class Board {
private:
	int upto[7]; // where we are upto in each column
	int board[7][6];
	bool turn;
public:
	enum { EMPTY, WHITE, BLACK };
	inline int getPiece(int x, int y) { return board[x][y]; }
	inline void setPiece(int x, int y, int val) { board[x][y] = val; }
	inline int getColumn(int xy) { return upto[xy]; }
	inline bool getTurn() { return turn; }
	void makeMove(Move);
	void unmakeMove(Move);
	void printBoard();
	void reset();
	Board() { reset(); }
};

#endif
