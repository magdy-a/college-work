
#include "SearchAgent.h"
#include "Evaluator.h"
#include <vector>
#include <iostream>

#define ED 1

Move SearchAgent::searchPosition(Board board)
{
	MoveGenerator mg;
	mg.generateMoves(board);
	std::vector<Move>& moves = mg.getMoves();
	
	int bestscore=-12000;
	int score=-11000;
	Move bestmove;
	bool lose=true;
	for (int i=0; i<moves.size(); i++)
	{
		board.makeMove(moves[i]);
		score = -minimax(board, 6);
		board.unmakeMove(moves[i]);

		if (ED == 1)
		std::cout << std::endl << "Score: " << score << " Best score: " << bestscore << " " <<
			moves[i].x << " , " << moves[i].y << std::endl;

		lose = false;

		if (score > 0) { return moves[i]; }

		if (score > bestscore)
		{
			bestscore = score;
			bestmove = moves[i];
		}
	}
	
	return bestmove;
}

int SearchAgent::minimax(Board& board, int depth)
{
	int k;
	if ((k = Evaluator::evaluate(board)) < -5000) { return k-depth; }
	if (depth == 0)
	{
		return Evaluator::evaluate(board);
	}

	depth--;
	MoveGenerator mg;
	mg.generateMoves(board);
	std::vector<Move>& moves = mg.getMoves();

	int score=-11000;
	int best=-12000;
	for (int i=0; i<moves.size(); i++)
	{
		board.makeMove(moves[i]);

		if (Evaluator::evaluate(board) < -5000) { 
			board.unmakeMove(moves[i]);
			return 10000+depth; 
		}


		score = -minimax(board, depth);
		if (score > 5000) { board.unmakeMove(moves[i]); return 10000+depth; }
		board.unmakeMove(moves[i]);

		if (score > best)
		{
			best = score;
	//		if (best > 5000) { return 10000+depth; }
		}
	}

	return best;
}