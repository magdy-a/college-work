
#include <windows.h>
#include <cstdio>
#include "Board.h"
#include "SearchAgent.h"
#include "Evaluator.h"
const char* szClassname = "AhmadsProg";

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	static Board board;
	static SearchAgent sa;
	static int x, y;
	static HBRUSH yellow, red, white;
	static bool comp = false;
	static bool gameend = false;
	switch (msg)
	{
	case WM_CREATE:
		{
			yellow = CreateSolidBrush(RGB(255,255,0));
			red = CreateSolidBrush(RGB(255,0,0));
			white = CreateSolidBrush(RGB(255,255,255));
		}
		break;
	case WM_CLOSE:
		DestroyWindow(hwnd);
		break;
	case WM_SIZE:
		{
			x = LOWORD(lParam);
			y = HIWORD(lParam);
		}
		break;
	case WM_LBUTTONDOWN:
		{
			Move move;
			move.type = Board::WHITE;
			int xco =  LOWORD(lParam);
			for (int i=0; i<7; i++)
			{
				if (xco > (x/7*(6-i)))
				{
					//char m[5];
					//sprintf(m, "%d", 6-i);
					//MessageBox(hwnd, m, ":)", MB_OK);
					move.x = 6-i;
					break;
				}
			}

			move.y = board.getColumn(move.x);
			if (board.getColumn(move.x) < 6)
			{
				board.makeMove(move);
				InvalidateRect(hwnd, NULL, true);
				comp = true;
			}
		}
	case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hDC = BeginPaint(hwnd, &ps);
			for (int k=0; k<6; k++)
			{
				for (int i=0; i<7; i++)
				{
					if (board.getPiece(i,5-k) == Board::EMPTY)
					{
						SelectObject(hDC, white);
					} else if (board.getPiece(i,5-k) == Board::BLACK)
					{
						SelectObject(hDC, red);
					} else if (board.getPiece(i,5-k) == Board::WHITE)
					{
						SelectObject(hDC, yellow);
					}
						Ellipse(hDC, x/7*(i)+10, y/6*(k)+10, x/7*(i+1)-10, y/6*(k+1)-10);
				}
			}
			EndPaint(hwnd, &ps);
			if (gameend)
			{
					MessageBox(hwnd, "You lost! Thank you for playing.",
						"Ahmads Connect-4 Prog!", MB_OK);
					gameend = false;
					board.reset();
					InvalidateRect(hwnd, NULL, true);
			}
			if (comp)
			{
				Move mv = sa.searchPosition(board);
				board.makeMove(mv);
				comp = false;
				if (Evaluator::evaluate(board) < -9999)
				{
					gameend = true;
				}
				InvalidateRect(hwnd, NULL, true);
			}
		}
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	default:
		return DefWindowProc(hwnd, msg, wParam, lParam);
	}
	return 0;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
				   LPSTR szCmdline, int iCmdShow)
{
	WNDCLASSEX wc;
	HWND hwnd;
	MSG msg;
 
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.style = CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc = WndProc;
	wc.hInstance = hInstance;
	wc.lpszClassName = szClassname;
	wc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wc.hIconSm = LoadIcon(NULL, IDI_APPLICATION);
	HBRUSH hBrush = CreateSolidBrush(RGB(0,0,255));
	wc.hbrBackground = hBrush;
	wc.lpszMenuName = NULL;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);

	if (!RegisterClassEx(&wc))
	{
		MessageBox(NULL, "Error occured registering class for application.",
					szClassname, MB_OK);
		return 0;
	}

	hwnd = CreateWindowEx(WS_EX_CLIENTEDGE, szClassname, "Ahmads Connect-4 Prog!", 
						WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, 
						600, 600, NULL, NULL, hInstance, NULL);

	if (hwnd == NULL)
	{
		MessageBox(NULL, "Window creation failed.", szClassname, MB_OK);
		return 0;
	}

	ShowWindow(hwnd, iCmdShow);
	UpdateWindow(hwnd);

	while (GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	
	return msg.wParam;
}