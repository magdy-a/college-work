
#include "Board.h"
#include "MoveGenerator.h"
#include "Move.h"
#include "Evaluator.h"
#include "SearchAgent.h"
#include <iostream>
using namespace std;


int main() 
{
    Board board;
	SearchAgent sa;
	int x;
	Move move, hmove;
	board.printBoard();
	while (true)
	{
		x=0;
		while ((x < 1) || (x > 7) || board.getColumn(x-1) == 6)
		{
			cout << "Enter x co-ordinate: ";
			cin >> x;
		}
		
	hmove.x = x-1;
	hmove.y = board.getColumn(x-1);
	hmove.type = Board::WHITE;
	board.makeMove(hmove);
    move = sa.searchPosition(board);
	cout << endl << move.x << " " << move.y << " " << move.type << endl;
	board.makeMove(move);
	board.printBoard();
	}
    return 0;
}
