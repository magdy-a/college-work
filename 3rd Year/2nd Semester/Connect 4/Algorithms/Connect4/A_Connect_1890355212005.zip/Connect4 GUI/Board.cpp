
#include <iostream>
#include <iomanip>
#include "Move.h"
#include "Board.h"

void Board::reset()
{
		turn = true;

		for (int i=0; i<7; i++) { 
			upto[i] = 0; }

		for (i=0; i<7; i++)
		{
			for (int k=0; k<6; k++)
			{
				board[i][k] = 0;
			}
		}
}

void Board::printBoard() 
{
	std::cout << std::endl;
for (int k=5; k>-1; k--)
{
     for (int i=0; i<7; i++)
     {              
		 if (board[i][k] == EMPTY)
        {
           std::cout << " - ";
        } else if (board[i][k] == WHITE)
        {
           std::cout << " W ";
        } else {
           std::cout << " B ";
        }
     }
     std::cout << std::endl;
}

std::cout << std::endl << " 1  2  3  4  5  6  7 " << std::endl;
}


void Board::makeMove(Move move)
{
	setPiece(move.x, move.y, move.type);
	upto[move.x]++;
	turn = !turn;
}

void Board::unmakeMove(Move move)
{
	setPiece(move.x, move.y, EMPTY);
	upto[move.x]--; 
	turn = !turn;
}
