 
#ifndef MOVEGENERATOR_H
#define MOVEGENERATOR_H

#include <vector>
#include "Board.h"
#include "Move.h"

class MoveGenerator {
private:
	std::vector<Move> moves;

public:
	std::vector<Move>& getMoves() { return moves; }
	void reset() { moves.clear(); }
	void generateMoves(Board);
};

#endif
