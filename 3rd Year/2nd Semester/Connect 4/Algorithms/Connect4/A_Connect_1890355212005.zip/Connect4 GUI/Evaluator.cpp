
#include "Evaluator.h"
#include "Board.h"

int Evaluator::evaluate(Board board)
{
	int eval = 0;
	for (int i=0; i<7; i++)
	{
		for (int k=0; k<6; k++)
		{
			if (i+3 < 7)
			{
					if ((board.getPiece(i+0, k) == Board::EMPTY) ||
						(board.getPiece(i+1, k) == Board::EMPTY) ||
						(board.getPiece(i+2, k) == Board::EMPTY) ||
						(board.getPiece(i+3, k) == Board::EMPTY))
					{

					} else if ((board.getPiece(i+0, k) == Board::WHITE) &&
								(board.getPiece(i+1, k) == Board::WHITE) &&
								(board.getPiece(i+2, k) == Board::WHITE) &&
								(board.getPiece(i+3, k) == Board::WHITE))
					{
						return (board.getTurn() ? 10000 : -10000);
					} else if ((board.getPiece(i+0, k) == Board::BLACK) &&
								(board.getPiece(i+1, k) == Board::BLACK) &&
								(board.getPiece(i+2, k) == Board::BLACK) &&
								(board.getPiece(i+3, k) == Board::BLACK))
					{
						return (board.getTurn() ? -10000 : 10000);
					}
			}

			if ((i+3 < 7) && (k+3 < 6))
			{
					if ((board.getPiece(i+0, k+0) == Board::EMPTY) ||
						(board.getPiece(i+1, k+1) == Board::EMPTY) ||
						(board.getPiece(i+2, k+2) == Board::EMPTY) ||
						(board.getPiece(i+3, k+3) == Board::EMPTY))
					{
						
					} else if ((board.getPiece(i+0, k+0) == Board::WHITE) &&
								(board.getPiece(i+1, k+1) == Board::WHITE) &&
								(board.getPiece(i+2, k+2) == Board::WHITE) &&
								(board.getPiece(i+3, k+3) == Board::WHITE))
					{
						return (board.getTurn() ? 10000 : -10000);
					} else if ((board.getPiece(i+0, k+0) == Board::BLACK) &&
								(board.getPiece(i+1, k+1) == Board::BLACK) &&
								(board.getPiece(i+2, k+2) == Board::BLACK) &&
								(board.getPiece(i+3, k+3) == Board::BLACK))
					{
						return (board.getTurn() ? -10000 : 10000);			
					}
			}

			if ((i-3 > -1) && (k+3 < 6))
			{
					if ((board.getPiece(i-0, k+0) == Board::EMPTY) ||
						(board.getPiece(i-1, k+1) == Board::EMPTY) ||
						(board.getPiece(i-2, k+2) == Board::EMPTY) ||
						(board.getPiece(i-3, k+3) == Board::EMPTY))
					{
						
					} else if ((board.getPiece(i-0, k+0) == Board::WHITE) &&
								(board.getPiece(i-1, k+1) == Board::WHITE) &&
								(board.getPiece(i-2, k+2) == Board::WHITE) &&
								(board.getPiece(i-3, k+3) == Board::WHITE))
					{
						return (board.getTurn() ? 10000 : -10000);
					} else if ((board.getPiece(i-0, k+0) == Board::BLACK) &&
								(board.getPiece(i-1, k+1) == Board::BLACK) &&
								(board.getPiece(i-2, k+2) == Board::BLACK) &&
								(board.getPiece(i-3, k+3) == Board::BLACK))
					{
						return (board.getTurn() ? -10000 : 10000);			
					}
			}

			if (k+3 < 6)
			{
					if ((board.getPiece(i, k+0) == Board::EMPTY) ||
						(board.getPiece(i, k+1) == Board::EMPTY) ||
						(board.getPiece(i, k+2) == Board::EMPTY) ||
						(board.getPiece(i, k+3) == Board::EMPTY))
					{
						
					} else if ((board.getPiece(i, k+0) == Board::WHITE) &&
							  (board.getPiece(i, k+1) == Board::WHITE) &&
							  (board.getPiece(i, k+2) == Board::WHITE) &&
							  (board.getPiece(i, k+3) == Board::WHITE))
					{
						return (board.getTurn() ? 10000 : -10000);
					} else if ((board.getPiece(i, k+0) == Board::BLACK) &&
							  (board.getPiece(i, k+1) == Board::BLACK) &&
							  (board.getPiece(i, k+2) == Board::BLACK) &&
							  (board.getPiece(i, k+3) == Board::BLACK))
					{
						return (board.getTurn() ? -10000 : 10000);
					}
			}


// extra eval features


			if (i+3 < 7)
			{
					if ((board.getPiece(i+0, k) == Board::WHITE) &&
								(board.getPiece(i+1, k) == Board::WHITE))
					{
						eval += (board.getTurn() ? 100 : -100);
						if (board.getPiece(i+2, k) == Board::WHITE)
							eval += (board.getTurn() ? 200 : -200);
					} else if ((board.getPiece(i+0, k) == Board::BLACK) &&
								(board.getPiece(i+1, k) == Board::BLACK))
					{
						eval += (board.getTurn() ? -100 : 100);
						if (board.getPiece(i+2, k) == Board::BLACK)
							eval += (board.getTurn() ? 200 : -200);
					}
			}

			if ((i+3 < 7) && (k+3 < 6))
			{
					 if ((board.getPiece(i+0, k+0) == Board::WHITE) &&
								(board.getPiece(i+1, k+1) == Board::WHITE))
					{
						eval += (board.getTurn() ? 100 : -100);
						if (board.getPiece(i+2, k+2) == Board::WHITE)
							eval += (board.getTurn() ? 200 : -200);
					} else if ((board.getPiece(i+0, k+0) == Board::BLACK) &&
								(board.getPiece(i+1, k+1) == Board::BLACK))
					{
						eval += (board.getTurn() ? -100 : 100);		
						if (board.getPiece(i+2, k+2) == Board::BLACK)
							eval += (board.getTurn() ? 200 : -200);
					}
			}

			if ((i-3 > -1) && (k-3 > -1))
			{
					 if ((board.getPiece(i-0, k-0) == Board::WHITE) &&
								(board.getPiece(i-1, k-1) == Board::WHITE))
					{
						eval += (board.getTurn() ? 100 : -100);
						if (board.getPiece(i-2, k-2) == Board::WHITE)
							eval += (board.getTurn() ? 200 : -200);
					} else if ((board.getPiece(i-0, k-0) == Board::BLACK) &&
								(board.getPiece(i-1, k-1) == Board::BLACK))
					{
						eval += (board.getTurn() ? -100 : 100);		
						if (board.getPiece(i-2, k-2) == Board::BLACK)
							eval += (board.getTurn() ? 200 : -200);
					}
			}

			if (k+3 < 6)
			{
					if ((board.getPiece(i, k+0) == Board::WHITE) &&
							  (board.getPiece(i, k+1) == Board::WHITE))
					{
						eval += (board.getTurn() ? 100 : -100);
						if (board.getPiece(i, k+2) == Board::WHITE)
							eval += (board.getTurn() ? 200 : -200);
					} else if ((board.getPiece(i, k+0) == Board::BLACK) &&
							  (board.getPiece(i, k+1) == Board::BLACK))
					{
						eval += (board.getTurn() ? -100 : 100);
						if (board.getPiece(i, k+2) == Board::BLACK)
							eval += (board.getTurn() ? 200 : -200);
					}
			}

			// end extra eval stuff

		}
	}

	return eval;
}