
#ifndef EVALUATOR_H
#define EVALUATOR_H

#include "Board.h"

class Evaluator {
public:
	static int evaluate(Board);
};

#endif