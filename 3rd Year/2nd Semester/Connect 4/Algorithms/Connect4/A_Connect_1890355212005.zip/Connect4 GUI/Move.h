
#ifndef MOVE_H
#define MOVE_H

struct Move {
	int x;
	int y;
	int type;
};

#endif
