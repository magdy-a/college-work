
#include "MoveGenerator.h" 
#include "Board.h"

void MoveGenerator::generateMoves(Board board)
{
	for (int i=0; i<7; i++)
	{
		if (board.getColumn(i) < 6)
		{
		Move move;
		move.x = i;
		move.y = board.getColumn(i);
		move.type = (board.getTurn() ? Board::WHITE : Board::BLACK);
		moves.push_back(move);
		}
	}

}
