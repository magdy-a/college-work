
#ifndef SEARCHAGENT_H
#define SEARCHAGENT_H

#include "Move.h"
#include "Board.h"
#include "MoveGenerator.h"

class SearchAgent {
	int minimax(Board& board, int depth);
public:
	Move searchPosition(Board board);
};

#endif