using System;
using System.Collections.Generic;
using System.Text;

namespace Connect4Console
{
    /// <summary>
    /// Player interface
    /// </summary>
    public interface IPlayer
    {
        int PlayerTurn(StateType state);
    }
}
