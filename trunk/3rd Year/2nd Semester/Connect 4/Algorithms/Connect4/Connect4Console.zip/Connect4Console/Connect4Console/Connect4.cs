using System;
using System.Collections.Generic;
using System.Text;

namespace Connect4Console
{
    /// <summary>
    /// Main game class
    /// </summary>
    public class Connect4
    {
        public StateType State; //Current game state
        public bool Winner; //Has a winner been found

        public IPlayer Player1; //Points to Player 1
        public IPlayer Player2; //Points to Player 2

        /// <summary>
        /// Finishes a turn for the current player
        /// </summary>
        /// <param name="Move"></param>
        /// <returns></returns>
        public bool Turn(int Move)
        {
            StateType st = State.Move(Move);
            if (st == null) return false;
            State = st;
            return true;
        }

        /// <summary>
        /// Plays a game of Connect 4.
        /// </summary>
        public void PlayGame()
        {
            int ww=0;
            while (!Winner)
            {

                if (State.Turn == 1) Turn(Player1.PlayerTurn(State));
                else Turn(Player2.PlayerTurn(State)); // No error handling yet
                ww = State.CheckWin(); //ww=0 => no winner yet, ww=1 => Player 1 wins, ww=2 => Player 2 wins, ww=-1 => Tie
                Winner = (ww != 0);

                Console.Clear();
                Console.WriteLine(State);
            }
            Console.Clear();
            Console.WriteLine("  * * *  CONNECT 4   * * * \n");
            Console.Write(State);
            if (ww == -1) Console.WriteLine(" ITS A TIE!!!");
            else Console.WriteLine("WE HAVE A WINNER: " + ((ww==1) ? "Player1" : "Player2"));
            Console.ReadLine();
        }

        public Connect4()
        {
            //Initialize
            Winner = false;
            State = new StateType();
            State.Turn = 1;
        }
    }

}
