using System;
using System.Collections.Generic;
using System.Text;

namespace Connect4Console
{
    /// <summary>
    /// Contains computer logic to calculate move.
    /// </summary>
    public class Computer : IPlayer
    {
        private int firstLevel = 0;

        /// <summary>
        /// Adjustable weights and Cut-off level.
        /// </summary>
        public int CutLevel = 6;
        public int[] Weights = new int[] { 1, 5, 100, 10000, 2, 6, 200, 15000 };

        #region Search algorithm based on MiniMax with Alpha Beta Pruning

        /// <summary>
        /// Minimax w. Alpha-Beta pruning modified to work with CutOff method and Heuristic Eval method.
        /// </summary>
        /// <param name="state"></param>
        /// <returns></returns>
        private int AlphaBetaSearch(StateType state)
        {
            state.Succesors = Successors(state); //Retrieve successors for current state.
            firstLevel = state.MoveCount; //Remember start state for cut-off function
            int j = MaxValue(state, int.MinValue, int.MaxValue); //Start recursive traversel of statespace
            //Pick which successor has action J.
            foreach (int a in state.Succesors.Keys)
            {
                if (state.Succesors[a].V == j) return a;
            }
            return -1;
        }

        /// <summary>
        /// Represents a Max-node (computer move). Picks option optimal for computer
        /// </summary>
        /// <param name="state"></param>
        /// <param name="Alpha"></param>
        /// <param name="Beta"></param>
        /// <returns></returns>
        private int MaxValue(StateType state, int Alpha, int Beta)
        {
            if (CutOffTest(state)) return state.V;  //Check for Cutoff.
            state.V = int.MinValue;
            Dictionary<int, StateType> succ = (state.Succesors != null) ? state.Succesors : Successors(state);
            foreach (int a in succ.Keys)
            {
                state.V = Math.Max(state.V, MinValue(succ[a], Alpha, Beta));
                if (state.V >= Beta) return state.V;
                Alpha = Math.Max(Alpha, state.V);
            }
            return state.V;
        }

        /// <summary>
        /// Represents Min-node (player move), picks option minimal for computer
        /// </summary>
        /// <param name="state"></param>
        /// <param name="Alpha"></param>
        /// <param name="Beta"></param>
        /// <returns></returns>
        private int MinValue(StateType state, int Alpha, int Beta)
        {
            if (CutOffTest(state)) return Eval(state.Values);
            state.V = int.MaxValue;
            Dictionary<int, StateType> succ = (state.Succesors != null) ? state.Succesors : Successors(state);
            foreach (int a in succ.Keys)
            {
                state.V = Math.Min(state.V, MaxValue(succ[a], Alpha, Beta));
                if (state.V <= Alpha) return state.V;
                Beta = Math.Min(Beta, state.V);
            }
            return state.V;
        }

        /// <summary>
        /// List possible successors states
        /// </summary>
        /// <param name="state"></param>
        /// <returns></returns>
        private Dictionary<int, StateType> Successors(StateType state)
        {
            Dictionary<int, StateType> succ = new Dictionary<int, StateType>(7);
            for (int i = 1; i <= 7; i++)
            {
                StateType st = state.Move(i); //If move is valid
                if (st != null) succ.Add(i, st);
            }
            return succ;
        }

        /// <summary>
        /// Simple CutOff. Checks for Win condition or only look 6 moves ahead.
        /// </summary>
        /// <param name="state"></param>
        /// <returns></returns>
        private bool CutOffTest(StateType state)
        {
            state.V = Eval(state.Values); //Check for Win situation
            if (Math.Abs(state.V)>5000) return true; //We have a terminal state
            if ((state.MoveCount - firstLevel) > CutLevel) return true; 
            return false;
        }


        #endregion

        #region Heuristic Evaluation
        /// <summary>
        /// Iterate through every possibility (4 fields)
        /// </summary>
        /// <param name="vals"></param>
        /// <returns></returns>
        private int CheckLine(params int[] vals)
        {
            int score = 0;
            for (int i = 0; i < (vals.Length - 3); i++)
            {
                //Examine each opportunity
                int c = 0;
                int p = 0;
                for (int j = 0; j < 4; j++)
                    if (vals[i + j] == number) c++; //TODO Make sure that it looks at it's own identity
                    else if (vals[i + j] !=0 ) p++;
                if ((c > 0) && (p == 0))
                {
                    //Computer opportunity
                    if (c == 4) return Weights[3]; //Win
                    score += ((c/3)*Weights[2]) + ((c/2)*Weights[1]) + Weights[0];
                }
                else if ((c == 0) && (p > 0))
                {
                    //Player opportunity
                    if (p == 4) return -1*Weights[7]; //Win
                    score -= ((p / 3) * Weights[6]) + ((p / 2) * Weights[5]) + Weights[4];
                }
            }
            return score;
        }


        /// <summary>
        /// Main Heuristic evaluation function
        /// </summary>
        /// <param name="state"></param>
        /// <returns></returns>
        private int Eval(int[,] state)
        {
            int score = 0;
            //Eval Horizontal
            for (int i = 0; i < 6; i++)
            {
                score += CheckLine(state[0, i], state[1, i], state[2, i], state[3, i], state[4, i], state[5, i], state[6, i]);
            }

            //Eval Vertical
            for (int i = 0; i < 7; i++)
            {
                score += CheckLine(state[i, 0], state[i, 1], state[i, 2], state[i, 3], state[i, 4], state[i, 5]);
            }

            //Eval Diagonal
            score += CheckLine(state[0, 2], state[1, 3], state[2, 4], state[3, 5]);
            score += CheckLine(state[0, 1], state[1, 2], state[2, 3], state[3, 4], state[4, 5]);
            score += CheckLine(state[0, 0], state[1, 1], state[2, 2], state[3, 3], state[4, 4], state[5, 5]);
            score += CheckLine(state[1, 0], state[2, 1], state[3, 2], state[4, 3], state[5, 4], state[6, 5]);
            score += CheckLine(state[2, 0], state[3, 1], state[4, 2], state[5, 3], state[6, 4]);
            score += CheckLine(state[3, 0], state[4, 1], state[5, 2], state[6, 3]);

            //Eval Diagonal 2
            score += CheckLine(state[3, 0], state[2, 1], state[1, 2], state[0, 3]);
            score += CheckLine(state[4, 0], state[3, 1], state[2, 2], state[1, 3], state[0, 4]);
            score += CheckLine(state[5, 0], state[4, 1], state[3, 2], state[2, 3], state[1, 4], state[0, 5]);
            score += CheckLine(state[6, 0], state[5, 1], state[4, 2], state[3, 3], state[2, 4], state[1, 5]);
            score += CheckLine(state[6, 1], state[5, 2], state[4, 3], state[3, 4], state[2, 5]);
            score += CheckLine(state[6, 2], state[5, 3], state[4, 4], state[3, 5]);
            return score; ;
        }

        #endregion

        /// <summary>
        /// Interface method that's being called by Connect4 every time it's the computers turn
        /// </summary>
        /// <param name="state">Current State</param>
        /// <returns>Action</returns>
        public int PlayerTurn(StateType state)
        {
            return AlphaBetaSearch(state); //Perform search to find best action
        }

        private int number;
        public Computer(int PlayerNumber)
        {
            number = PlayerNumber;
        }
    }
}
