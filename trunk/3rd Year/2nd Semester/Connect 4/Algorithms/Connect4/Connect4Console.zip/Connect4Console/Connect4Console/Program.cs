using System;
using System.Collections.Generic;
using System.Text;

namespace Connect4Console
{
    class Program
    {
        /// <summary>
        /// Main method, executes game
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            Connect4 c4 = new Connect4();
            c4.Player1 = new Human();
            c4.Player2 = new Computer(2);

            //Uncomment this code to allow computer vs computer games:
            //c4.Player1 = new Computer(1);
            //(c4.Player1 as Computer).CutLevel = 7;
            //(c4.Player2 as Computer).Weights = new int[] { 1, 5, 100, 10000, 1, 5, 200, 15000 };
            
            c4.PlayGame();

        }
    }
}
