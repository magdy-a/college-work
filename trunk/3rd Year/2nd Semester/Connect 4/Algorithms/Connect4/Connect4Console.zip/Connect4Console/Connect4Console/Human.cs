using System;
using System.Collections.Generic;
using System.Text;

namespace Connect4Console
{
    /// <summary>
    /// Class that interfaces to the Human player.
    /// </summary>
    public class Human : IPlayer
    {

        public int PlayerTurn(StateType state)
        {
            Console.Clear();
            Console.WriteLine("  * * *  CONNECT 4   * * * \n");
            Console.WriteLine(state);
            Console.Write("Whats your move (1-7)?");
            char c = Console.ReadKey().KeyChar;
            int m = int.Parse(c.ToString()); //Currently no validation of input
            return m;           
        }

        public Human()
        {
        }
    }
}
