using System;
using System.Collections.Generic;
using System.Text;

namespace Connect4Console
{
    /// <summary>
    /// Describes a state
    /// </summary>
    public class StateType
    {
        public int[,] Values; //Board: horizontal, vertical
        public int[] RowCounts; //Number of occupied fields in each column.
        public int Turn; //Current Player
        public int V; //State Value
        public int MoveCount; //Moves made
        public Dictionary<int, StateType> Succesors; //Cache Action-Successors pairs storage for first node.

        /// <summary>
        /// Create a new state, after a move.
        /// </summary>
        /// <param name="M">A number 1-7 for the column to be choosen in the move</param>
        /// <returns>The result state</returns>
        public StateType Move(int M)
        {
            StateType st = new StateType(this); //Clone current state
            int m = M - 1;
            if (st.RowCounts[m] == 6) return null; //If column is full, return null. Illegal action
            st.RowCounts[m]++;
            st.Values[m, (6 - st.RowCounts[m])] = st.Turn; //Update board
            st.Turn = (st.Turn==1)? 2:1; //Change turn
            st.MoveCount++;
            return st;
        }


        #region Check for Win situation
        /// <summary>
        /// Iterate through every possibility (4 fields)
        /// </summary>
        /// <param name="vals"></param>
        /// <returns>0 if no winner, otherwise winner number.</returns>
        private int CheckLine(params int[] vals)
        {
            int last = 0;
            int lastcount = 0;
            for (int i = 0; i < vals.Length ; i++)
            {
                if (vals[i] == last) lastcount++;
                else { last = vals[i]; lastcount = 1; }
                if ((lastcount == 4) && (last > 0)) break;
            }
            if ((lastcount == 4) && (last > 0)) return last;
            return 0;
        }


        /// <summary>
        /// Check for a winner
        /// </summary>
        /// <returns>0 if no winner. Otherwise winner</returns>
        public int CheckWin()
        {
            int r=0;
            //Check Horizontal
            for (int i = 0; i < 6; i++)
            {
                r= CheckLine(Values[0, i], Values[1, i], Values[2, i], Values[3, i], Values[4, i], Values[5, i], Values[6, i]);
                if (r != 0) return r;
            }

            //Check Vertical
            for (int i = 0; i < 7; i++)
            {
                r = CheckLine(Values[i, 0], Values[i, 1], Values[i, 2], Values[i, 3], Values[i, 4], Values[i, 5]);
                if (r != 0) return r;
            }

            //Check Diagonal
            r= CheckLine(Values[0, 2], Values[1, 3], Values[2, 4], Values[3, 5]);
            if (r != 0) return r;
            r= CheckLine(Values[0, 1], Values[1, 2], Values[2, 3], Values[3, 4], Values[4, 5]);
            if (r != 0) return r;
            r= CheckLine(Values[0, 0], Values[1, 1], Values[2, 2], Values[3, 3], Values[4, 4], Values[5, 5]);
            if (r != 0) return r;
            r= CheckLine(Values[1, 0], Values[2, 1], Values[3, 2], Values[4, 3], Values[5, 4], Values[6, 5]);
            if (r != 0) return r;
            r= CheckLine(Values[2, 0], Values[3, 1], Values[4, 2], Values[5, 3], Values[6, 4]);
            if (r != 0) return r;
            r= CheckLine(Values[3, 0], Values[4, 1], Values[5, 2], Values[6, 3]);
            if (r != 0) return r;
            //Check Diagonal 2
            r= CheckLine(Values[3, 0], Values[2, 1], Values[1, 2], Values[0, 3]);
            if (r != 0) return r;
            r= CheckLine(Values[4, 0], Values[3, 1], Values[2, 2], Values[1, 3], Values[0, 4]);
            if (r != 0) return r;
            r= CheckLine(Values[5, 0], Values[4, 1], Values[3, 2], Values[2, 3], Values[1, 4], Values[0, 5]);
            if (r != 0) return r;
            r= CheckLine(Values[6, 0], Values[5, 1], Values[4, 2], Values[3, 3], Values[2, 4], Values[1, 5]);
            if (r != 0) return r;
            r= CheckLine(Values[6, 1], Values[5, 2], Values[4, 3], Values[3, 4], Values[2, 5]);
            if (r != 0) return r;
            r= CheckLine(Values[6, 2], Values[5, 3], Values[4, 4], Values[3, 5]);
            if (r != 0) return r;

            //Check for full (=tie)
            bool empty=false;
            for (int i = 0; i < this.RowCounts.Length; i++)
                if (RowCounts[i] < 6) { empty = true; break; }
            if (!empty) return -1;
            return 0;
        }
        #endregion

        /// <summary>
        /// Build Console Output showing current state.
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("\t1\t2\t3\t4\t5\t6\t7\n\n");
            for (int j = 0; j < 6; j++)
            {
                for (int i = 0; i < 7; i++)
                {
                    sb.Append("\t" + ((Values[i, j] == 0) ? "*" : ((Values[i, j] == 1) ? "1" : "2")));
                }
                sb.Append("\n\n");
            }
            sb.Append("\n\nMoves: " + MoveCount.ToString() + "\nNext Turn: Player " + Turn.ToString() + "\n");
            return sb.ToString();
        }

        /// <summary>
        /// Construct new state based on old.
        /// </summary>
        /// <param name="orig"></param>
        public StateType(StateType orig)
        {
            Values = (int[,])orig.Values.Clone();
            RowCounts = (int[])orig.RowCounts.Clone();
            Turn = orig.Turn;
            MoveCount = orig.MoveCount;
        }

        /// <summary>
        /// Construct new state
        /// </summary>
        public StateType()
        {
            Values = new int[7, 6]; //Initialize the board to 7x6
            RowCounts = new int[7];
            MoveCount = 0;
        }
    }
}
