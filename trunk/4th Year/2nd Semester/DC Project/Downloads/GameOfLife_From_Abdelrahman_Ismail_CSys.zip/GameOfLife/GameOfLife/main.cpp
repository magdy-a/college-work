#include <windows.h>
#include <gl/gl.h>
#include <gl/glut.h>
#include <iostream>
#include <fstream>
#include <string>
#include "FramerateDisplayer.h"

using namespace std;

#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "glu32.lib")
#pragma comment(lib, "glut32.lib")

FramerateDisplayer *fr;
int size = 5;
int *matrix;
int *matrix2;
int frameCount;
int currentTime;
int previousTime;
float fps = 0;
char d_text[20];
/**
Creates the main window, registers event handlers, and
initializes OpenGL stuff.
*/
void InitGraphics(int argc, char *argv[]);

/**
Sets the logical coordinate system we will use to specify
our drawings.
*/
void SetTransformations();

/**
Handles the paint event. This event is triggered whenever
our displayed graphics are lost or out-of-date.
ALL rendering code should be written here.
*/
void OnDisplay();

void CalculateFPS();

int main(int argc, char* argv[]) {
	fr = new FramerateDisplayer();
	fr->init(0.05,GLUT_BITMAP_HELVETICA_18,0,0,0,0.0,0.0);
	string line;
	ifstream myfile ("C:\\output.txt");
	int i = 0;
	if (myfile.is_open())
	{
		while ( myfile.good() )
		{
			getline (myfile,line);

			if (i >= size)
				continue;

			if (i == 0) {
				size = atoi(line.c_str());
				matrix = new int[size*size];
				matrix2 = new int[size*size];
			}
			else {
				const char* charLine = line.c_str();
				for(int j = 0; j < size; j++) {
					matrix[(i-1)*size+j] = charLine[j] - '0';
					matrix2[(i-1)*size+j] = matrix[(i-1)*size+j];
				}
			}
			i++;
		}
		myfile.close();
	}
	else cout << "Unable to open file"; 
	
	InitGraphics(argc, argv);

	return 0;
}

void Idle(void)
{
	CalculateFPS();
	fr->anotherFrameExecuted();
	OnDisplay();
}

/**
Creates the main window, registers event handlers, and
initializes OpenGL stuff.
*/
void InitGraphics(int argc, char *argv[]) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGBA);
	//Create an 800x600 window with its top-left corner at pixel (100, 100)
	glutInitWindowPosition(100, 100); //pass (-1, -1) for Window-Manager defaults
	glutInitWindowSize(800, 600);
	glutCreateWindow("OpenGL Lab");
	//OnDisplay will handle the paint event
	glutDisplayFunc(OnDisplay);
	glutIdleFunc(Idle);
	glutMainLoop();
}
 
/**
Sets the logical coordinate system we will use to specify
our drawings.
*/
void SetTransformations() {
	//set up the logical coordinate system of the window: [-100, 100] x [-100, 100]
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(-size/2, size/2, -size/2, size/2);
}

void CalculateFPS()
{
    //  Increase frame count
    frameCount++;

    //  Get the number of milliseconds since glutInit called
    //  (or first call to glutGet(GLUT ELAPSED TIME)).
    currentTime = glutGet(GLUT_ELAPSED_TIME);

    //  Calculate time passed
    int timeInterval = currentTime - previousTime;

    if(timeInterval > 1000)
    {
        // calculate the number of frames per second
        fps = frameCount / (timeInterval / 1000.0f);
		sprintf(d_text,"Framerate: %f",fps);
        // Set time
        previousTime = currentTime;
		
        // Reset frame count
        frameCount = 0;
    }
}

void CalculateFrame()
{
	memcpy(matrix2,matrix,size*sizeof(int));

	for (int i = 0; i < size; i++)
	{
		for (int j = 0; j < size; j++)
		{
			int neighbors = 0;
			for (int x = -1; x <= 1; x++)
			{
				for (int y = -1; y <= 1; y++)
				{
					if (i+y>=size || i+y < 0 || j+x>=size || i+x < 0 || (x==0 && y == 0))
						continue;
					if (matrix2[(i+y)*size + (j+x)] == 1)
					{
						neighbors++;
					}
				}
			}
			
			if (neighbors >= 3)
				matrix[i*size+j] = 1;
			else if (neighbors < 2)
				matrix[i*size+j] = 0;
		}
	}

	for (int i = 0; i < size; i++)
	{
		for (int j = 0; j < size; j++)
		{
			matrix2[i*size+j] = matrix[i*size+j];
		}
	}
}

/**
Handles the paint event. This event is triggered whenever
our displayed graphics are lost or out-of-date.
ALL rendering code should be written here.
*/
void OnDisplay() {
	//set the background color to white
	glClearColor(1, 1, 1, 1);
	//fill the whole color buffer with the clear color
	glClear(GL_COLOR_BUFFER_BIT);
	
	SetTransformations();

	CalculateFrame();

	//drawing code goes here
	glBegin(GL_POINTS);

	for (int i = 0; i < size; i++)
	{
		for (int j = 0; j < size; j++)
		{
			int value = matrix[i*size+j];
			if (value)
				glColor3f(1, 0, 0);
			else
				glColor3f(1, 1, 1);
			glVertex2f(i-size/2,j-size/2);
		}
	}
	glEnd();
	
	fr->displayFramerate(d_text);
	
	//force previously issued OpenGL commands to begin
	//execution
	glFlush();
}
