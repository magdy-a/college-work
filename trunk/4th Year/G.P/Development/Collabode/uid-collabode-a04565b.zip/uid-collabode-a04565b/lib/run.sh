#!/bin/bash

export JAVA_HOME="/System/Library/Frameworks/JavaVM.framework/Versions/1.6/Home"

bin/run-local.sh
