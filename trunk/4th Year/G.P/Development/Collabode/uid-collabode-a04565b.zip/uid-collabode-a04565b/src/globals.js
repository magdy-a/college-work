var COMETPATH = "/comet";
