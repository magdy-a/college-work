package collabode;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * Functionality needs implementation.
 */
@Target(ElementType.METHOD)
public @interface NeedsImpl {

}
