package collabode;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * Reviewed and accepted.
 */
@Target(ElementType.METHOD)
public @interface Accepted {

}
