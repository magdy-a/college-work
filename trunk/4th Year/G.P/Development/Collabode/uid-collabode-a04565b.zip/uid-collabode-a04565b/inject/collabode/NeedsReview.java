package collabode;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * Functionality implemented, test needs review.
 */
@Target(ElementType.METHOD)
public @interface NeedsReview {

}
